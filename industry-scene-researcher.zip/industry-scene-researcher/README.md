# Industry Scene Researcher / 行业场景研究员

把模糊的行业目标收敛成 AI 助手可执行的落地方案：锁定一个最高价值工作流缺口，输出"五件套"——场景补位卡、AI 落地作战路径、人机混编任务表、3 天试点行动包、唯一下一步。

## 适用场景

- 只有行业/角色/目标的模糊需求 → 快速收敛主缺口（quick_judgement）
- 手上有政策、客户、竞品、会议材料 → 证据增强的缺口判断与试点包（material_to_output）
- 已有方案要推进落地 → Day 1 行动清单、一页汇报卡（continue_action）

## 包结构

```
industry-scene-researcher/
├── agents/industry-scene-researcher.md        ← 主 agent：分流、五件套合同、无外部依赖主线
├── skills/industry-scene-methodology/SKILL.md ← 方法论合同：证据账本、交付环、能力分层、创意库规范
├── references/
│   ├── workflows/                             ← 创意库指南、政策方向扫描、工作流缺口手册
│   └── quality/verification-gates.md          ← 质量门槛
├── library/
│   ├── industry-scene-creative-library.jsonl  ← 24 张场景创意卡（offline/online/stakeholder）
│   └── industry-scene-creative-library.schema.json
└── examples/policy-direction-ledger-202606.json ← 政策来源账本填写示例
```

## 边界

- 不绑定任何特定 AI 平台或宿主；首值在任何对话式 AI 助手中即可交付。
- 外部工具、自动化、联网检索均为可选增强，不是首值前提。
- 行业数据必须挂来源证据账本；无来源的判断标 `needs_verification`。
