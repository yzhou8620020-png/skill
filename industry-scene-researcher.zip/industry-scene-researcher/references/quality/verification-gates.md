# Verification Gates

## F: First Value

- `first_value_gate`: five outputs must be present: `supplementCard`, `aiCapabilityMap`, `humanAiTaskTable`, `pilotPacket`, `singleNextStepCta`.
- `context_gate`: the response must lock at least `userIndustry`, `userRole`, and `userGoal` before choosing one workflow gap.
- `single_gap_gate`: only one primary workflow gap is allowed to advance into the pilot packet.
- `highest_value_gap_evidence_gate`: when claiming the highest-value gap, the winner must keep at least one evidence row or be explicitly labeled as `highestValueGapIsHypothesis`.
- `scenario_micro_slice_gate`: before the five-part bundle is finalized, the chosen gap must be grounded in one concrete `actor / moment / blockedAction / AIIntervention / humanDecision / observableArtifact` slice.

## N: No External Dependency

- `no_external_dependency_gate`: first value must stay usable without any external connector, plugin, or service runtime.
- `no_fake_write_gate`: claiming "generated / written to workspace" requires a real file write in the current turn; otherwise state "content delivered, not yet materialized".

## C: Continuation

- `continued_use_gate`: the CTA must push the user toward a 3-day pilot packet or project action packet instead of stopping at a static result card.
- `single_cta_gate`: exploratory routing may offer choices, but the final delivery must converge on one highest-priority next step.

## CL: Creative Library

- `creative_schema_gate`: every JSONL row must include the schema-required fields.
- `creative_context_gate`: every JSONL row must include `persona_anchor`, `timing_pattern`, `format_strategy`, and `evolution_evidence_note`.
- `creative_tag_gate`: `offline` / `online` / `stakeholder` must all be covered.
- `creative_count_gate`: the seed library must contain at least 20 cards.
- `next_step_gate`: each card must contain exactly one `unique_next_step`.
- `boundary_gate`: each card must state a human approval boundary for external commitment or activation.
- `evidence_bind_gate`: each card must include at least one source evidence row.
- `timing_pattern_gate`: cards must state whether they are primarily pre-meeting, in-meeting, post-meeting, or full-cycle.
- `format_strategy_gate`: cards must match output format to reader cognitive load.
- `artifact_load_gate`: cards using preview, HTML, PDF, image, or auto-loaded outputs must declare those outputs explicitly.
- `automation_safe_gate`: cards using automation must declare paused-by-default behavior.

## CE: Creative Enhancement Boundary

- `creative_no_dependency_gate`: cards must not make external connectors or service runtimes a prerequisite for first value.
- `creative_optional_remote_gate`: assistant, mobile push, bot push, and connector routes must be labeled optional.
- `creative_single_cta_gate`: enhancement exploration may offer choices, but final card execution still ends with one next step.
- `policy_evidence_gate`: when a card is triggered by latest policy direction, it must map policy text into one concrete workflow gap, include `sourceUrl`, `retrievedAt`, `evidenceStrength`, and `clientUseStatus`, and avoid turning policy direction into direct business-closure claims.
- `policy_repost_boundary_gate`: `authoritative_repost` rows are allowed for internal mapping only; customer-facing citation requires primary URL review before the row can be treated as directly citable.
