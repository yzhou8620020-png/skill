# Workflow Gap Playbook

用于 `shortcut.workflow-gap`：

1. 先锁定单个最高价值工作流缺口。
2. 给四维评分（业务价值、数据就绪度、AI 适配度、执行就绪度）。
3. 盘点 AI 助手能力。
4. 输出人机分工表。
5. 输出 3 天试点行动包。
6. 用唯一 CTA 推进到执行。
