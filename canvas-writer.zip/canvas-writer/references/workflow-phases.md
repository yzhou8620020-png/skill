# 阶段工作流细则

本文件在执行具体阶段时读取。`SKILL.md` 只负责判断当前阶段和路由；进入任一阶段后，按本文推进。

## 阶段与轮次

阶段机只有四个状态，全部围绕"把画布填满"：

```text
FILL（逐格填写）→ VERIFY（验证四问）→ CONFIRM（终稿前确认）→ DONE（终稿落盘）
```

round 是一次用户交互。所有阶段遵守单焦点原则：**每轮只问一个格子 / 一个验证问题**。

每轮提问前必须做两件事：
1. 调 `focus` 把当前格子标记到台账（HTML 画布会高亮该格为"正在咨询"）。
2. 读取 `references/interaction-frames.md` 选择输出格式。

## 开工（创建台账）

需求方发起后，第一轮只问一个问题：**产品叫什么名字？想给它一个什么代号、赋予什么意义？**（PPT 产品名称格，示例：京东通天塔、青龙订单系统、阿米巴、太阳花、赛马。）

需求方回答后：
1. 推导 slug（产品核心概念的英文短语，全小写连字符，2-4 个词，如 `pet-fresh-food`）。
2. 初始化台账（`product_name` 以 round=0 锁定，阶段为 FILL）：

```bash
node scripts/canvas-cli.mjs init \
  --slug <slug> --product-name <"产品名称与代号含义"> --output-dir docs/canvas/<slug>
```

3. **告诉需求方打开 HTML 画布**：`docs/canvas/<slug>/canvas-<slug>.html`（浏览器打开即可，页面自动刷新，会看到画布一格格被填上）。

不做任何画布之外的前置提问——没有画像问卷，没有定性问卷，产品名称之后直接进入画布第一格。

## FILL 逐格填写

**每轮第一步：查 next 确认当前格子（强制）**

不要凭记忆挑格子，以台账为权威：

```bash
node scripts/canvas-cli.mjs next --ledger <path>
```

输出下一个待填格子的 id、所属分区、以及该格子的 PPT 引导问题清单。分区顺序 basics → demand → production → growth → competition → finance 由脚本兜底，**前一分区未填满不会给出下一分区的格子**。

**每轮流程：**
1. `next` 拿到目标格子和引导问题。
2. `focus --field <id>` 让 HTML 高亮该格。
3. 按 `references/interaction-frames.md` 的"填格轮"格式，用该格子的 PPT 引导问题向需求方提问。**只用 PPT 的问题，不发明新问题**；一格内问题多时可归并为一次提问，但不跨格。
4. 需求方回答后，把回答整理为格子内容，`lock` 入账（`--source` 记录信息来源：需求方口述 / 用户访谈 / 数据 / 估算）。
5. 回答与已锁格子矛盾时（例如价值主张对不上用户任务），指出矛盾，先让需求方澄清再锁。
6. 回答太模糊无法入格时，用该格子清单里更具体的那条 PPT 问题追问一轮（例如关键业务答不出就问"为什么是这个，不是其他？"；用户画像空泛就问"上一次访谈在什么时候？"）。

**回答质量的判断标准以 PPT 为准**（见 `references/methodology.md`）：
- 用户画像：答不出"每周和用户聊多久 / 上次访谈时间"的，内容以"待验证"标注入格，验证阶段第 1、2 问必须给访谈/调研动作。
- 用户任务：要有起点 → 终点和方案优先级。
- 内部伙伴：目标罗列 10 个，并能说出 KPI；实际没有那么多就如实记录。
- 竞争·差异化：说"没有竞品"时，问 PPT 原问题"用户使用哪些替代方案？"；声称蓝海时，用公式"蓝海 = 场景差异化 + 旧要素重新组合"检验。
- LTV：LT、ARPU 给不出实数可用估算，但要记下口径（ARPU = 周期收入 / 周期活跃用户数）。

21 个填写格全部锁定后（`progress` 显示 fill_complete），调 `set-phase --phase VERIFY`。

## VERIFY 验证四问

对应 PPT 验证模块。四问逐轮确认，每轮 1 问，顺序固定：

1. `v_market` 市场大么？痛点存在么？
2. `v_useful` 有用么？有人用么？
3. `v_feasible` 能做出来么？能竞争赢么？
4. `v_cac` 用户价值是否大于获客成本？获客效率高么？

每轮流程：
1. `focus --field <v_id>`。
2. 按"验证轮"格式提问：重述该问，引用画布已填格子作为证据（对应关系见 `references/canvas-fields.md` 验证分区表），请需求方确认证据是否成立。
3. 结论 + 依据 + 验证手段（市场调研 / 用户访谈 / 预售测试）整理后 `lock` 该 v_ 字段。已有证据的记"已验证 + 证据"；没有的记"待验证 + 计划动作"。
4. 某一问被动摇、需要改画布内容时：`set-phase --phase FILL` 回退，修改对应格子后再回 VERIFY（四问需要重新过——脚本会把已锁的 v_ 字段保留，但被修改格子关联的 v_ 问应主动重新确认）。

四问全部锁定后，调 `set-phase --phase CONFIRM`。

## CONFIRM 终稿前确认

1. `summary` 输出全部已锁格子的值，供需求方逐格确认。
2. 需求方确认无误 → 进入终稿落盘。
3. 需求方要求修改 → `set-phase --phase FILL` 回退，改完重新走 VERIFY 中被影响的问。

## DONE 终稿落盘

1. 读取 `references/canvas-template.md`，撰写终稿到 `docs/canvas/<slug>/.canvas-draft-<slug>.md`。终稿内容全部来自已锁格子，不新增。
2. 落盘：

```bash
node scripts/canvas-cli.mjs save-canvas --ledger <path> \
  --content docs/canvas/<slug>/.canvas-draft-<slug>.md --output-dir docs/canvas/<slug>
```

3. 脚本校验结构（头部 slug、七大模块章节齐全）后写入 `CANVAS-<slug>-<YYYYMMDD-HHMM>.md`，删除草稿，阶段标记 DONE，HTML 画布切到"已完成"状态。
4. 回报终稿和 HTML 的绝对路径。终稿落盘并校验成功前，不得输出 `DONE` 状态行。
