# 台账与脚本协议

本文件在需要读取、创建、更新、回滚或落盘时读取。JSON 台账是权威源；Markdown 台账和 **HTML 画布**都是渲染视图，每次写操作后由脚本自动刷新。所有命令统一走 `scripts/canvas-cli.mjs`。

## 工作区与产物

每个项目用自己的 slug 子目录隔离：

```text
docs/canvas/<slug>/
  ledger-state-<slug>.json      # 权威源
  canvas-ledger-<slug>.md       # 台账 Markdown 视图（只读）
  canvas-<slug>.html            # 实时画布视图（浏览器打开，自动刷新）
  .canvas-draft-<slug>.md       # 终稿草稿（落盘后自动删除）
  CANVAS-<slug>-<YYYYMMDD-HHMM>.md  # 最终交付物
```

写产物只写 `docs/canvas/<slug>/`。

## HTML 实时画布

- `canvas-<slug>.html` 以 PPT 画布的版式呈现全部格子：未填格子显示该格的引导问题（灰字），已填格子显示内容，**当前 focus 的格子高亮并标注"正在咨询"**，最近一次锁定的格子有填入动画。
- 页面每 2 秒自动刷新（meta refresh），需求方在浏览器保持打开即可看到画布被一格格填上。
- init 成功后的第一轮回复中，把 HTML 路径告诉需求方并请其用浏览器打开。
- HTML 由脚本在每次 `init` / `lock` / `focus` / `set-phase` / `save-canvas` 后自动重渲，AI 不要手写 HTML。

## 创建台账

需求方回答产品名称后执行：

```bash
node scripts/canvas-cli.mjs init \
  --slug <slug> --product-name <"产品名称与代号含义"> --output-dir docs/canvas/<slug>
```

脚本会：自动 mkdir；创建 JSON 台账（`product_name` 以 round=0 锁定，阶段 FILL）；渲染 Markdown 台账和 HTML 画布。

## 跨会话恢复

新会话开始先检查 `docs/canvas/<slug>/`：

- **台账存在**：`progress` 读取 `current_phase` / `current_round`，继续。
- **不存在**：从头开工（问产品名称 → init）。

## 常用命令

```bash
node scripts/canvas-cli.mjs next     --ledger <path>   # 下一个待填格子 + 该格 PPT 引导问题（每轮提问前必调）
node scripts/canvas-cli.mjs focus    --ledger <path> --field <id>   # 标记当前咨询格子，HTML 高亮
node scripts/canvas-cli.mjs progress --ledger <path>   # 阶段、轮次、填写进度
node scripts/canvas-cli.mjs status   --ledger <path>   # 全部格子明细（口令"展开状态"）
node scripts/canvas-cli.mjs summary  --ledger <path>   # 已锁格子全览（CONFIRM 阶段用）
node scripts/canvas-cli.mjs render   --ledger <path>   # 手动重渲 Markdown + HTML
```

口令映射：`展开状态` → `status`；`只看缺口` → `next`；`生成终稿前摘要` → `summary`。

## 轮次号（round）语义

round 是"用户对话轮次"——每发一次面向需求方的提问、收到答复后写台账，记一次 round。

- 一轮通常 1 次 `lock`；本轮如果同时锁字段又推进阶段，`lock` 与 `set-phase` 用同一个 round 号。
- 只读查询（`next` / `progress` / `status`）和 `focus` 不消耗 round。
- 报错重试的 `lock` 不消耗 round。

每轮开始查 `progress`，直接用输出的 `next_round` 作为本轮 `--round`。

## lock

```bash
node scripts/canvas-cli.mjs lock \
  --ledger <path> \
  --fields-file <临时 JSON 文件路径> \
  --round <n> \
  --quote "需求方原话摘要"
```

fields JSON 数组（每次只锁 1 个格子）：

```json
[
  {
    "id": "demand_scenario",
    "value": "深夜喂奶后想快速记录，双手被占用，操作窗口不到 30 秒；痛点是记录中断 → 诉求是单手 10 秒完成",
    "source": "用户访谈"
  }
]
```

`source` 记录信息来源：`需求方口述` / `用户访谈` / `数据` / `估算` / `待验证`。

规则（脚本硬校验）：
- FILL 阶段只能锁填写格（非 `v_*`），且必须按分区顺序——`next` 给出的格子才是合法目标，跳分区会被 `section_order` 拒绝。
- VERIFY 阶段只能锁 `v_*` 四个验证字段，同样按顺序。
- 每次 `lock` 只允许 1 个字段。
- 已锁字段可以再次 `lock`（修改），会记入变更日志。

## set-phase 合法转移图

```text
FILL    → VERIFY   （需 21 个填写格全部锁定）
VERIFY  → CONFIRM  （需 4 个验证问全部锁定）| FILL（回退修改）
CONFIRM → FILL     （需求方要求修改）
DONE    → FILL     （reopen）
```

`CONFIRM → DONE` 仅由 `save-canvas` 触发，不允许手动 set-phase DONE。

```bash
node scripts/canvas-cli.mjs set-phase --ledger <path> --phase <target> --round <n>
```

非法转移返回 `error: 'invalid_transition'`，附 `from_phase` 与 `allowed_targets`。

## 回滚

需求方说 `回滚到上一轮` 时：

```bash
node scripts/canvas-cli.mjs rollback --ledger <path>
```

回滚追加独立变更记录，轮次编号继续递增，不回退。

## 终稿落盘

CONFIRM 阶段需求方确认后，撰写草稿到 `.canvas-draft-<slug>.md`，然后：

```bash
node scripts/canvas-cli.mjs save-canvas --ledger <path> \
  --content docs/canvas/<slug>/.canvas-draft-<slug>.md \
  --output-dir docs/canvas/<slug>
```

脚本硬校验：
- 当前 `phase === 'CONFIRM'`，否则 `error: 'phase_guard'`。
- 25 个格子全部锁定，否则 `error: 'fields_incomplete'`。
- 终稿结构：头部标题与 slug、`## 0. 画布一页总览`、七大模块章节、`## 附录` 齐全，否则 `error: 'structure_invalid'` 并列出缺失项。

通过后写入 `CANVAS-<slug>-<YYYYMMDD-HHMM>.md`，删除草稿，阶段标记 DONE，重渲 HTML（完成态）。落盘完成后回报绝对路径。
