# canvas-writer

独立可用的"项目创新画布"搭建工具：以单题逐轮的方式，把 PPT《产品经理的项目创新画布》的 25 个格子逐格问完、逐格填上。提问只用画布格子自带的问题，不延展。全程生成**实时 HTML 画布**——需求方在浏览器中看着画布被一格格填写，当前咨询的格子高亮。

## 做什么

- 开工只问 1 题（产品名称与代号）即建档，之后直接进画布第一格
- FILL 阶段按 PPT 画布分区顺序逐格提问：基础信息 → 需求 → 方案 → 增长 → 竞争 → 财务
- VERIFY 阶段过 PPT 验证四问：市场大么痛点存在么 / 有用么有人用么 / 能做出来么能竞争赢么 / 用户价值是否大于获客成本
- 每次提问前高亮 HTML 画布中的当前格子；每答完一格实时填入（页面自动刷新）
- 产出创新画布终稿：一页总览 + 七大模块 + 验证表

## 使用方式

对话触发（"帮我做产品立项 / 整理成创新画布"），运行入口见 [SKILL.md](./SKILL.md)。

## 产物说明

每个项目独占一个目录：`docs/canvas/<slug>/`。

| 文件 | 类型 | 说明 |
|------|------|------|
| `ledger-state-<slug>.json` | 权威源 | 画布台账：格子状态、轮次日志、当前焦点 |
| `canvas-ledger-<slug>.md` | 视图 | 台账 Markdown 视图；只读 |
| `canvas-<slug>.html` | 视图 | **实时画布**：浏览器打开自动刷新，未填格显示引导问题，当前格高亮"正在咨询"，新填格有动画 |
| `.canvas-draft-<slug>.md` | 临时草稿 | 落盘成功后自动删除 |
| `CANVAS-<slug>-<YYYYMMDD-HHMM>.md` | 最终交付物 | 创新画布终稿 |

## 脚本目录

```text
canvas-writer/scripts/
  canvas-cli.mjs          # 唯一读写入口：init / lock / focus / set-phase / rollback /
                          # next / progress / status / summary / render / save-canvas
  canvas-smoke.test.mjs   # 行为锁定测试
```

## 参考文件

```text
canvas-writer/references/
  workflow-phases.md     # 开工 / FILL / VERIFY / CONFIRM / DONE 执行细则
  canvas-fields.md       # 25 个格子与各格 PPT 引导问题全集
  methodology.md         # PPT 方法论知识沉淀（判断回答质量的唯一依据）
  interaction-frames.md  # 填格轮 / 验证轮 / 确认轮输出格式
  ledger-protocol.md     # 台账与脚本协议、HTML 渲染
  canvas-template.md     # 终稿模板
```

## 验收

```bash
node --test canvas-writer/scripts/canvas-smoke.test.mjs
```
