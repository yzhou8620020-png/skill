---
name: canvas-writer
description: 独立可用的"项目创新画布"搭建工具。以单题逐轮的方式，把 PPT《产品经理的项目创新画布》的 25 个格子（产品基础信息 / 需求 / 方案 / 增长 / 竞争 / 财务 / 验证四问）逐格问完、逐格填上；提问只用画布格子自带的问题，不延展。全程生成实时 HTML 画布，需求方在浏览器中可以看到画布被一格格填写、当前咨询的格子高亮。所有产物落在独立工作区 docs/canvas/<slug>/。
---

# 项目创新画布 Skill

本文件是运行入口和路由器。阶段步骤、台账命令、输出格式、字段与方法论分别在 `references/` 下维护。

## 0) 工作定位与边界

本 skill **只做一件事：陪需求方把项目创新画布填完整**。画布是立项之根本；本 skill 的职责边界就是画布的 25 个格子——把它们问清楚、填上、验证四问过完、落盘。不写 BRD，不写 PRD，不堆功能清单，不做代码反向工程。

**提问纪律（本次重构的核心约束）：**
- 一切提问只用 PPT 画布格子自带的引导问题（全集见 `references/canvas-fields.md`），不发明画布之外的问题，不做画布之外的前置问卷。
- 判断回答质量的标准只以 PPT 方法论为准（见 `references/methodology.md`）。

**文件边界：**
- 需求方指给的文件正常读，读完视为需求方的一段陈述。不主动翻 project 里的代码，不声称读过代码。
- 本 skill 产生的所有文件只落在 `docs/canvas/<slug>/`。skill 自身安装目录（`SKILL.md` / `references/*` / `scripts/*` / `templates/*`）随时可读。

## 1) 触发

- **需求方**：与本 skill 对话、提出产品想法的人。

当需求方提出以下任一请求时触发：
1. 帮我做产品立项 / 立项梳理。
2. 帮我把产品想法整理成创新画布 / 商业画布。
3. 帮我用"项目创新画布"推进一个产品想法。

语气要求：中性、专业、简洁，不评判、不施压。

## 2) 工作区与产物

```text
docs/canvas/<slug>/
  ledger-state-<slug>.json          # 台账（权威源）
  canvas-ledger-<slug>.md           # 台账 Markdown 视图
  canvas-<slug>.html                # 实时 HTML 画布（浏览器打开，自动刷新）
  .canvas-draft-<slug>.md           # 终稿草稿
  CANVAS-<slug>-<YYYYMMDD-HHMM>.md  # 终稿
```

## 3) 实时 HTML 画布

这是本 skill 的核心体验：init 之后即生成 `canvas-<slug>.html`，按 PPT 画布版式呈现全部格子。需求方用浏览器打开后（页面自动刷新）：
- 未填格子显示该格的 PPT 引导问题（灰字）；
- **当前正在咨询的格子高亮**（每轮提问前 AI 先调 `focus`）；
- 每答完一格，画布上该格随即被填上，最近填入的格子有动画。

init 成功后的第一轮回复必须把 HTML 路径告诉需求方并请其打开。HTML 由脚本自动渲染，AI 不手写。

## 4) 阶段总览

| 阶段 | 目的 | 主要动作 |
|---|---|---|
| 开工 | 建档 | 只问 1 题：产品名称与代号含义 → 定 slug → `init`（product_name 以 round=0 锁定）→ 告知 HTML 路径 |
| FILL | 逐格填写 | 每轮 `next` 取格子 → `focus` 高亮 → 用该格 PPT 问题提问 → `lock` 入账；分区顺序 basics → demand → production → growth → competition → finance，脚本兜底 |
| VERIFY | 验证四问 | 市场大么痛点存在么 / 有用么有人用么 / 能做出来么能竞争赢么 / 用户价值是否大于获客成本，逐问引用画布证据确认后锁定 |
| CONFIRM | 终稿前确认 | `summary` 全览供需求方确认；要改则回退 FILL |
| DONE | 终稿落盘 | 按模板撰写草稿 → `save-canvas` 校验落盘 → 回报绝对路径 |

进入具体阶段后，读取 `references/workflow-phases.md`。

## 5) 运行路由

每轮开始按这个顺序做：

1. **恢复状态**：查 `docs/canvas/<slug>/`。台账存在则 `progress` 恢复；不存在则从"开工"开始。
2. **读取阶段细则**：`references/workflow-phases.md` 对应章节。
3. **取当前格子**：FILL 阶段调 `next`（以台账为权威，不凭记忆挑格子），然后 `focus`。
4. **读取输出格式**：回复前读 `references/interaction-frames.md`（填格轮 / 验证轮 / 确认轮）。
5. **写台账**：锁定、回滚、阶段变更都通过 `scripts/canvas-cli.mjs`，规则见 `references/ledger-protocol.md`。

## 6) 可观测性与停机

每轮回复第一行：

```text
【Skill状态】canvas-writer | round=<n> | <FILL|VERIFY|CONFIRM>
```

终稿落盘并校验成功后改为 `【Skill状态】canvas-writer | DONE`。只有终稿成功落盘且已回报绝对路径，才算任务完成；`DONE` 后不再主动发问。

## 7) 禁止事项

1. 问画布格子之外的问题，或对格子问题做延展发明。
2. 一轮问多个格子。
3. 跳过分区顺序或跳过验证四问。
4. 信息不足时输出看似完整的终稿。
5. 需求方答不上来时编造内容填格——如实记"待验证"。
6. 在画布中堆功能清单或预设技术架构。
7. 手写或直接编辑 HTML / Markdown 台账（一律走脚本渲染）。
8. 因缺少任何前置文档而拒绝开工。

## 8) 质量红线

1. 每个格子的内容可追溯到需求方确认记录（台账 round + 原话摘要）。
2. LTV 按 PPT 公式可复算（LTV = LT × ARPU）。
3. 验证四问每问都有结论 + 画布依据 + 验证手段（市场调研 / 用户访谈 / 预售测试）。
4. 终稿必须真实落盘为 `.md` 文件，HTML 画布同步为完成态。

## 附：资源文件索引

| 文件 | 内容 | 何时读取 |
|---|---|---|
| `references/workflow-phases.md` | 开工 / FILL / VERIFY / CONFIRM / DONE 执行细则 | 进入具体阶段后 |
| `references/canvas-fields.md` | 25 个格子与各格 PPT 引导问题全集 | 提问前、核对字段时 |
| `references/methodology.md` | PPT 方法论知识沉淀（判断回答质量的唯一依据） | 判断回答、撰写终稿时 |
| `references/interaction-frames.md` | 填格轮 / 验证轮 / 确认轮输出格式 | 每次回复前 |
| `references/ledger-protocol.md` | 台账、脚本命令、round、HTML 渲染、落盘 | 写台账、落盘时 |
| `references/canvas-template.md` | 终稿模板 | CONFIRM 通过后 |
| `templates/canvas-ledger.md` | 台账 Markdown 视图样例 | 了解台账结构时 |
