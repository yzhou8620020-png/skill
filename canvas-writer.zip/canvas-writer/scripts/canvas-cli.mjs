#!/usr/bin/env node
/**
 * canvas-cli.mjs — 项目创新画布台账 CLI（唯一读写入口）
 *
 * JSON 台账是权威源；Markdown 台账和 HTML 实时画布都是渲染视图，
 * 每次写操作后自动刷新。字段与引导问题严格对应 PPT 画布的 25 个格子。
 *
 * 命令一览：
 *   init         创建台账（product_name 以 round=0 锁定，阶段 FILL）
 *   next         下一个待填格子 + 该格 PPT 引导问题（每轮提问前必调）
 *   focus        标记当前咨询格子（HTML 高亮"正在咨询"）
 *   lock         锁定一个格子（按分区顺序硬校验）
 *   set-phase    阶段推进 FILL → VERIFY → CONFIRM（DONE 仅由 save-canvas 触发）
 *   rollback     回滚最近一次锁定
 *   progress / status / summary  只读查询
 *   render       手动重渲 Markdown + HTML
 *   save-canvas  校验终稿结构并落盘，标记 DONE
 *
 * 所有输出为单个 JSON 对象：{ success: true, ... } 或 { success: false, error, ... }
 */

import fs from 'node:fs';
import path from 'node:path';

// ---------------------------------------------------------------------------
// 画布定义（与 references/canvas-fields.md 保持一致，问题全部取自 PPT 原文）
// ---------------------------------------------------------------------------

const SECTIONS = [
  { id: 'basics',      label: '产品基础信息',           hint: '定位：为什么此刻做？成了怎么算？' },
  { id: 'demand',      label: '需求（为谁设计）',        hint: '定位的起点，是用户+场景+任务' },
  { id: 'production',  label: '方案（以什么方式生产）',  hint: '你伙伴的关系，决定了你能否做成这款产品' },
  { id: 'growth',      label: '增长（以什么方式规模化）', hint: '引导用户完成任务，才能交付产品价值' },
  { id: 'competition', label: '竞争',                   hint: '活过明天=特殊洞察+增长与留存效率；活过后天=非对称优势+增长与留存效率' },
  { id: 'finance',     label: '财务',                   hint: 'LTV = LT × ARPU；探索期降固定成本，扩张期降可变成本' },
  { id: 'validation',  label: '验证',                   hint: '验证手段：市场调研 / 用户访谈 / 预售测试' },
];

// 顺序即 FILL 阶段的提问顺序；verify: true 的字段在 VERIFY 阶段锁定
const FIELD_DEFS = [
  { id: 'product_name', label: '产品名称', section: 'basics',
    questions: ['产品代号是什么？赋予它什么意义？（示例：京东通天塔系统 / 青龙订单系统 / 阿米巴系统 / 太阳花系统 / 赛马系统）'] },
  { id: 'product_goal', label: '产品目标', section: 'basics',
    questions: ['公司/投资人对产品的目标预期是什么？在有限的时间，如何达成？', '目标类型是哪种：打开XX市场 / 遏制XX竞争 / 丰富内容类型 / 磨合团队 / 盈利 / 防守？'] },
  { id: 'product_metrics', label: '产品指标', section: 'basics',
    questions: ['对成果的检测方式是什么？团队与公司的价值共识用哪个指标承载？（示例：市场占有率 / 渗透率 / NPS满意度 / DAU / 留存率 / ROI）'] },
  { id: 'schedule', label: '计划周期', section: 'basics',
    questions: ['明确时间节点及资源投入：什么时间点，投入什么资源，到什么程度？'] },

  { id: 'user_profile', label: '用户画像', section: 'demand',
    questions: ['用户是谁？生活在怎样的环境？他如何生活？如何工作？', '他喜欢什么？恐惧什么？', '你了解产品的用户么？你每周和他们聊多久？上一次访谈在什么时候？'] },
  { id: 'demand_scenario', label: '需求场景', section: 'demand',
    questions: ['在什么场景下，用户有需求？用户的动机是什么？', '哪些因素对用户行为有影响？用户心理状态是什么？', '用户痛点是什么？对应的用户诉求是什么？'] },
  { id: 'user_task', label: '用户任务', section: 'demand',
    questions: ['用户要达成的目标是什么？用户为什么要达成这个目标？', '用户的状态会有什么改变？用户会有什么收益？', '从起点到终点有哪几条解决方案？优先级如何？'] },

  { id: 'value_proposition', label: '价值主张', section: 'production',
    questions: ['通过什么产品/服务达成？为什么他有效果？为什么用户相信？', '句式：帮助 xxx 在 xxx 下完成 xxx，解决/达成/以便 xxxx。'] },
  { id: 'key_business', label: '关键业务', section: 'production',
    questions: ['产品需要哪些业务行为支持？', '哪一项业务行为对产品影响最大？为什么是这个，不是其他？'] },
  { id: 'core_resources', label: '核心资源&能力', section: 'production',
    questions: ['哪些资源对产品成功影响最大？', '为什么是这个资源，不是其他？'] },
  { id: 'internal_partners', label: '重要伙伴（内部）', section: 'production',
    questions: ['有哪些合作伙伴？罗列至少 10 个。', '他们的 KPI 是什么？你知道吗？', '他们看中什么？我们能否提供？'] },
  { id: 'external_partners', label: '重要伙伴（外部）', section: 'production',
    questions: ['哪些合作方对产品成功影响重大？', 'TA 们配合交付的效率如何？', '他们看中什么？我们能否提供？'] },

  { id: 'user_connection', label: '用户连接', section: 'growth',
    questions: ['用户会在哪些场景留意产品信息？什么会吸引用户的兴趣？', '用户为什么想了解产品？用户如何去体验产品？'] },
  { id: 'user_success', label: '用户成功', section: 'growth',
    questions: ['如何帮助用户解决问题？', '如何衡量用户任务的完成度？'] },
  { id: 'relationship_growth', label: '关系发展', section: 'growth',
    questions: ['如何衡量产品与用户的关系？如何帮助产品与用户提升关系？', '（手段：会员体系 / 新手引导 / 任务奖励系统设计 / 社区化）'] },

  { id: 'diff_advantage', label: '差异化优势', section: 'competition',
    questions: ['列举：用户使用哪些替代方案？', '特殊洞察：与竞品相比，我们对用户/场景/任务，有什么不同理解？', '（蓝海市场 = 场景差异化 + 旧要素重新组合：新供给｜新技术｜新连接）'] },
  { id: 'production_advantage', label: '生产效率优势', section: 'competition',
    questions: ['列举：有哪些组织和我们有类似的关键业务、核心资源、核心能力？', '非对称优势：相比之下，我们有哪些认知优势、资源优势、能力优势？'] },
  { id: 'growth_advantage', label: '增长效率', section: 'competition',
    questions: ['列举：有哪些组织和我们的用户连接、用户成功、关系发展策略相似？', '我们的增长与留存效率如何？'] },

  { id: 'ltv', label: '用户终身价值', section: 'finance',
    questions: ['LT（用户平均生命周期）是多少？', 'ARPU（平均用户收入 = 周期收入 / 周期活跃用户数）是多少？', 'LTV = LT × ARPU = ？（例：LT=3 个月，ARPU=10 元/月，LTV=30 元）'] },
  { id: 'revenue_structure', label: '收入构成', section: 'finance',
    questions: ['收入来源有哪些种类？', '不同类别收入的健康度及价值如何？（时时刻刻衡量收入的健康程度）'] },
  { id: 'cost_structure', label: '成本构成', section: 'finance',
    questions: ['固定成本有哪些？可变成本有哪些？', '（探索期降低固定成本，扩张期降低可变成本）'] },

  { id: 'v_market', label: '市场大么？痛点存在么？', section: 'validation', verify: true,
    questions: ['市场大么？痛点存在么？（依据：用户画像 / 需求场景 / 用户任务；验证手段：市场调研）'] },
  { id: 'v_useful', label: '有用么？有人用么？', section: 'validation', verify: true,
    questions: ['有用么？有人用么？（依据：价值主张 / 用户成功；验证手段：用户访谈 / 预售测试）'] },
  { id: 'v_feasible', label: '能做出来么？能竞争赢么？', section: 'validation', verify: true,
    questions: ['能做出来么？能竞争赢么？（依据：方案分区 / 竞争分区）'] },
  { id: 'v_cac', label: '用户价值是否大于获客成本？', section: 'validation', verify: true,
    questions: ['用户价值是否大于获客成本？获客效率高么？（依据：用户终身价值 / 用户连接 / 成本构成）'] },
];

const SOURCES = ['需求方口述', '用户访谈', '数据', '估算', '待验证'];

// 阶段转移图；CONFIRM → DONE 仅由 save-canvas 触发
const PHASE_TRANSITIONS = {
  FILL:    ['VERIFY'],
  VERIFY:  ['CONFIRM', 'FILL'],
  CONFIRM: ['FILL'],
  DONE:    ['FILL'],
};

// ---------------------------------------------------------------------------
// 通用工具
// ---------------------------------------------------------------------------

function nowStamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function fileStamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
}

function out(obj) {
  process.stdout.write(JSON.stringify(obj, null, 2) + '\n');
  process.exit(obj.success === false ? 1 : 0);
}

function fail(error, extra = {}) {
  out({ success: false, error, ...extra });
}

function parseArgs(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      const key = argv[i].slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) {
        args[key] = true;
      } else {
        args[key] = next;
        i++;
      }
    }
  }
  return args;
}

function loadLedger(args) {
  if (!args.ledger) fail('missing_arg', { hint: '需要 --ledger <path>' });
  if (!fs.existsSync(args.ledger)) fail('ledger_not_found', { path: args.ledger });
  try {
    return JSON.parse(fs.readFileSync(args.ledger, 'utf8'));
  } catch (e) {
    fail('ledger_parse_error', { detail: String(e) });
  }
}

function saveLedger(args, ledger) {
  ledger.header.updated_at = nowStamp();
  fs.writeFileSync(args.ledger, JSON.stringify(ledger, null, 2) + '\n', 'utf8');
  const dir = path.dirname(args.ledger);
  fs.writeFileSync(path.join(dir, `canvas-ledger-${ledger.header.slug}.md`), renderMarkdown(ledger), 'utf8');
  fs.writeFileSync(path.join(dir, `canvas-${ledger.header.slug}.html`), renderHtml(ledger), 'utf8');
}

function loadJsonFile(p, argName) {
  if (!p) fail('missing_arg', { hint: `需要 --${argName} <path>` });
  if (!fs.existsSync(p)) fail('file_not_found', { path: p });
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (e) {
    fail('json_parse_error', { path: p, detail: String(e) });
  }
}

function fillFields(ledger) { return ledger.fields.filter((f) => !f.verify); }
function verifyFields(ledger) { return ledger.fields.filter((f) => f.verify); }
function nextOpenField(ledger) {
  const pool = ledger.header.phase === 'VERIFY' ? verifyFields(ledger) : fillFields(ledger);
  return pool.find((f) => f.status === 'open') ?? null;
}

function valueToText(v) {
  if (v === null || v === undefined) return '—';
  if (Array.isArray(v)) return v.join('；');
  return String(v);
}

// ---------------------------------------------------------------------------
// Markdown 渲染
// ---------------------------------------------------------------------------

function renderMarkdown(ledger) {
  const h = ledger.header;
  const lines = [];
  lines.push(`# 创新画布决策台账 - ${h.product_name}`);
  lines.push('');
  lines.push(`> 生成时间: ${h.created_at}`);
  lines.push(`> 最后更新: ${h.updated_at}`);
  lines.push(`> 当前轮次: ${h.current_round}`);
  lines.push(`> 当前阶段: ${h.phase}`);
  lines.push(`> project_slug: ${h.slug}`);
  lines.push('> Skill: canvas-writer');
  lines.push('');
  lines.push('<!-- 本文件由 scripts/canvas-cli.mjs 自动渲染，只读，不要手动编辑。实时画布见同目录 canvas-*.html -->');
  lines.push('');
  lines.push('## 1. 画布格子状态');
  lines.push('');
  lines.push('| # | 分区 | 格子 | 内容 | 状态 | 轮次 | 来源 |');
  lines.push('|---|------|------|------|------|------|------|');
  ledger.fields.forEach((f, i) => {
    const sec = SECTIONS.find((s) => s.id === f.section)?.label ?? f.section;
    lines.push(`| ${i + 1} | ${sec} | ${f.label} | ${f.status === 'locked' ? valueToText(f.value) : '—'} | ${f.status} | ${f.round ?? '—'} | ${f.source ?? '—'} |`);
  });
  lines.push('');
  lines.push('## 2. 轮次变更日志');
  lines.push('');
  if (ledger.changelog.length === 0) {
    lines.push('（暂无记录）');
  } else {
    for (const entry of ledger.changelog) {
      lines.push(`### Round ${entry.round}${entry.kind === 'rollback' ? '（回滚）' : ''}`);
      lines.push(`- **时间**: ${entry.at}`);
      lines.push(`- **动作**: ${entry.action}`);
      for (const c of entry.changes) {
        lines.push(`- \`${c.label}\`: ${valueToText(c.old_value)}(${c.old_status}) → ${valueToText(c.new_value)}(${c.new_status})`);
      }
      if (entry.quote) lines.push(`- **需求方原话摘要**: ${entry.quote}`);
      lines.push('');
    }
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------------------
// HTML 实时画布渲染
// ---------------------------------------------------------------------------

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function cellHtml(ledger, field) {
  const classes = ['cell', field.status === 'locked' ? 'filled' : 'open'];
  if (ledger.header.focus_field === field.id && ledger.header.phase !== 'DONE') classes.push('focus');
  if (ledger.header.last_locked === field.id) classes.push('just-filled');
  const badge = classes.includes('focus') ? '<span class="badge">正在咨询</span>'
    : field.status === 'locked' ? '<span class="check">✓</span>' : '';
  const body = field.status === 'locked'
    ? `<div class="val">${escapeHtml(valueToText(field.value))}</div>${field.source ? `<div class="src">来源：${escapeHtml(field.source)}</div>` : ''}`
    : `<ul class="qs">${field.questions.map((q) => `<li>${escapeHtml(q)}</li>`).join('')}</ul>`;
  return `<div class="${classes.join(' ')}" id="cell-${field.id}"><div class="cell-head"><h3>${escapeHtml(field.label)}</h3>${badge}</div>${body}</div>`;
}

function sectionBlock(ledger, sectionId, extraClass = '') {
  const sec = SECTIONS.find((s) => s.id === sectionId);
  const fields = ledger.fields.filter((f) => f.section === sectionId);
  const done = fields.filter((f) => f.status === 'locked').length;
  return `<section class="module ${extraClass}" data-sec="${sectionId}">
<div class="module-head"><h2>${escapeHtml(sec.label)}</h2><span class="count">${done}/${fields.length}</span><p class="hint">${escapeHtml(sec.hint)}</p></div>
<div class="cells cells-${sectionId}">${fields.map((f) => cellHtml(ledger, f)).join('\n')}</div>
</section>`;
}

function renderHtml(ledger) {
  const h = ledger.header;
  const total = ledger.fields.length;
  const locked = ledger.fields.filter((f) => f.status === 'locked').length;
  const pct = Math.round((locked / total) * 100);
  const done = h.phase === 'DONE';
  const focusField = ledger.fields.find((f) => f.id === h.focus_field);
  const phaseLabel = { FILL: '逐格填写中', VERIFY: '验证四问中', CONFIRM: '终稿确认中', DONE: '画布已完成' }[h.phase] ?? h.phase;

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
${done ? '' : '<meta http-equiv="refresh" content="2">'}
<title>创新画布 · ${escapeHtml(h.product_name)}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
         background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); min-height: 100vh;
         color: #1f2937; padding: 24px; }
  .top { max-width: 1280px; margin: 0 auto 20px; color: #fff; display: flex; align-items: center;
         gap: 16px; flex-wrap: wrap; }
  .top h1 { font-size: 22px; font-weight: 700; }
  .top .sub { color: #94a3b8; font-size: 13px; }
  .phase { padding: 4px 14px; border-radius: 999px; font-size: 13px; font-weight: 600;
           background: ${done ? '#10b981' : '#3b82f6'}; color: #fff; }
  .progress { flex: 1; min-width: 200px; display: flex; align-items: center; gap: 10px; }
  .bar { flex: 1; height: 10px; background: rgba(255,255,255,.15); border-radius: 999px; overflow: hidden; }
  .bar i { display: block; height: 100%; width: ${pct}%; border-radius: 999px;
           background: linear-gradient(90deg, #22d3ee, #34d399); transition: width .6s ease; }
  .progress span { font-size: 13px; color: #cbd5e1; white-space: nowrap; }
  .board { max-width: 1280px; margin: 0 auto; display: grid; gap: 14px; }
  .mid { display: grid; grid-template-columns: 1fr 1.4fr 1fr; gap: 14px; }
  @media (max-width: 960px) { .mid { grid-template-columns: 1fr; } }
  .module { background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1);
            border-radius: 16px; padding: 14px; }
  .module-head { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
  .module-head h2 { color: #f1f5f9; font-size: 15px; }
  .module-head .count { color: #34d399; font-size: 12px; font-weight: 700; }
  .module-head .hint { width: 100%; color: #64748b; font-size: 11px; }
  .cells { display: grid; gap: 10px; }
  .cells-basics { grid-template-columns: repeat(4, 1fr); }
  .cells-competition, .cells-finance { grid-template-columns: repeat(3, 1fr); }
  .cells-validation { grid-template-columns: repeat(4, 1fr); }
  @media (max-width: 960px) { .cells-basics, .cells-competition, .cells-finance, .cells-validation { grid-template-columns: 1fr 1fr; } }
  .cell { background: #fff; border-radius: 12px; padding: 12px; min-height: 96px;
          border: 2px solid transparent; position: relative; }
  .cell.open { background: rgba(255,255,255,.92); }
  .cell.filled { background: #ecfdf5; border-color: #a7f3d0; }
  .cell.focus { border-color: #f59e0b; box-shadow: 0 0 0 4px rgba(245,158,11,.25);
                animation: pulse 1.6s ease-in-out infinite; }
  .cell.just-filled { animation: fillin .8s ease-out; }
  @keyframes pulse { 0%,100% { box-shadow: 0 0 0 4px rgba(245,158,11,.25);} 50% { box-shadow: 0 0 0 9px rgba(245,158,11,.08);} }
  @keyframes fillin { from { transform: scale(.96); background: #fef9c3; } to { transform: scale(1); background: #ecfdf5; } }
  .cell-head { display: flex; align-items: center; justify-content: space-between; gap: 6px; margin-bottom: 6px; }
  .cell-head h3 { font-size: 13px; color: #111827; }
  .badge { background: #f59e0b; color: #fff; font-size: 10px; padding: 2px 8px; border-radius: 999px; white-space: nowrap; }
  .check { color: #10b981; font-weight: 800; }
  .qs { list-style: none; }
  .qs li { font-size: 11px; color: #9ca3af; line-height: 1.5; padding-left: 10px; position: relative; }
  .qs li::before { content: "·"; position: absolute; left: 0; }
  .val { font-size: 12px; color: #065f46; line-height: 1.6; white-space: pre-wrap; }
  .src { margin-top: 6px; font-size: 10px; color: #6b7280; }
  .footer { max-width: 1280px; margin: 16px auto 0; color: #475569; font-size: 11px; text-align: center; }
  .done-banner { max-width: 1280px; margin: 0 auto 16px; background: linear-gradient(90deg,#059669,#10b981);
                 color: #fff; padding: 12px 18px; border-radius: 12px; font-size: 14px; font-weight: 600; }
</style>
</head>
<body>
<div class="top">
  <h1>项目创新画布 · ${escapeHtml(h.product_name)}</h1>
  <span class="phase">${phaseLabel}</span>
  <div class="progress"><div class="bar"><i></i></div><span>${locked}/${total} 格（${pct}%）</span></div>
  <span class="sub">round ${h.current_round} · 更新于 ${escapeHtml(h.updated_at)}${done ? '' : ' · 页面每 2 秒自动刷新'}</span>
</div>
${done ? '<div class="done-banner">✓ 画布已完成并落盘终稿。</div>' : ''}
${focusField && !done ? '' : ''}
<div class="board">
${sectionBlock(ledger, 'basics')}
<div class="mid">
${sectionBlock(ledger, 'demand')}
${sectionBlock(ledger, 'production')}
${sectionBlock(ledger, 'growth')}
</div>
${sectionBlock(ledger, 'competition')}
${sectionBlock(ledger, 'finance')}
${sectionBlock(ledger, 'validation')}
</div>
<div class="footer">canvas-writer · 产品经理的项目创新画布：立项之根本 · project_slug: ${escapeHtml(h.slug)}</div>
</body>
</html>`;
}

// ---------------------------------------------------------------------------
// 命令实现
// ---------------------------------------------------------------------------

function cmdInit(args) {
  const errors = [];
  if (!args.slug) errors.push({ arg: 'slug', hint: '必填' });
  if (!args['product-name']) errors.push({ arg: 'product-name', hint: '必填' });
  if (!args['output-dir']) errors.push({ arg: 'output-dir', hint: '必填' });
  if (errors.length > 0) fail('invalid_args', { errors });

  const dir = args['output-dir'];
  fs.mkdirSync(dir, { recursive: true });
  const ledgerPath = path.join(dir, `ledger-state-${args.slug}.json`);
  if (fs.existsSync(ledgerPath)) fail('ledger_exists', { path: ledgerPath, hint: '台账已存在，用 progress 恢复，不要重复 init' });

  const fields = FIELD_DEFS.map((f) => ({
    id: f.id, label: f.label, section: f.section, questions: f.questions,
    ...(f.verify ? { verify: true } : {}),
    status: 'open', value: null, round: null, source: null,
  }));
  const nameField = fields.find((f) => f.id === 'product_name');
  nameField.status = 'locked';
  nameField.value = args['product-name'];
  nameField.round = 0;
  nameField.source = '需求方口述';

  const ledger = {
    header: {
      skill: 'canvas-writer', slug: args.slug, product_name: args['product-name'],
      created_at: nowStamp(), updated_at: nowStamp(),
      current_round: 0, phase: 'FILL', focus_field: null, last_locked: 'product_name',
    },
    fields,
    changelog: [],
  };

  const fakeArgs = { ledger: ledgerPath };
  fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n', 'utf8');
  saveLedger(fakeArgs, ledger);
  out({
    success: true,
    ledger: path.resolve(ledgerPath),
    html: path.resolve(path.join(dir, `canvas-${args.slug}.html`)),
    hint: '请把 html 路径告诉需求方，用浏览器打开即可实时看到画布被填写',
  });
}

function cmdNext(args) {
  const ledger = loadLedger(args);
  const phase = ledger.header.phase;
  if (phase === 'CONFIRM' || phase === 'DONE') {
    out({ success: true, phase, next_field: null, hint: phase === 'CONFIRM' ? '全部格子已锁定，用 summary 输出全览供需求方确认' : '画布已完成' });
  }
  const field = nextOpenField(ledger);
  if (!field) {
    out({ success: true, phase, next_field: null,
      hint: phase === 'FILL' ? '21 个填写格已全部锁定，set-phase VERIFY 进入验证四问' : '验证四问已全部锁定，set-phase CONFIRM 进入终稿确认' });
  }
  const sec = SECTIONS.find((s) => s.id === field.section);
  out({
    success: true, phase,
    next_field: { id: field.id, label: field.label, section: field.section, section_label: sec.label, questions: field.questions },
    section_hint: sec.hint,
    reminder: '提问前先 focus 该字段，让 HTML 画布高亮',
  });
}

function cmdFocus(args) {
  const ledger = loadLedger(args);
  if (!args.field) fail('missing_arg', { hint: '需要 --field <id>' });
  const field = ledger.fields.find((f) => f.id === args.field);
  if (!field) fail('unknown_field', { id: args.field });
  ledger.header.focus_field = field.id;
  ledger.header.last_locked = null; // 新焦点出现后不再重播上一格的填入动画
  saveLedger(args, ledger);
  out({ success: true, focus: field.id, label: field.label });
}

function cmdLock(args) {
  const ledger = loadLedger(args);
  const round = Number(args.round);
  if (!Number.isInteger(round) || round < 1) fail('invalid_round', { hint: '--round 必须是 >=1 的整数，用 progress 的 next_round' });
  const items = loadJsonFile(args['fields-file'], 'fields-file');
  if (!Array.isArray(items) || items.length !== 1) fail('single_field_only', { hint: '每次 lock 只允许 1 个格子' });
  const item = items[0];

  const phase = ledger.header.phase;
  if (phase !== 'FILL' && phase !== 'VERIFY') fail('phase_guard', { from_phase: phase, hint: 'lock 只允许在 FILL 或 VERIFY 阶段执行' });

  const field = ledger.fields.find((f) => f.id === item.id);
  if (!field) fail('unknown_field', { id: item.id });
  if (phase === 'FILL' && field.verify) fail('phase_field_mismatch', { id: item.id, hint: '验证四问在 VERIFY 阶段锁定' });
  if (phase === 'VERIFY' && !field.verify) fail('phase_field_mismatch', { id: item.id, hint: 'VERIFY 阶段只锁验证四问；要改填写格先 set-phase FILL' });

  // 分区顺序硬校验：新锁定的格子必须是当前 next 目标；已锁格子可以修改
  if (field.status === 'open') {
    const expected = nextOpenField(ledger);
    if (expected && expected.id !== field.id) {
      fail('section_order', { expected: expected.id, expected_label: expected.label, got: field.id,
        hint: '按画布分区顺序推进，先锁 next 给出的格子' });
    }
  }

  if (typeof item.value !== 'string' && !Array.isArray(item.value)) fail('type_mismatch', { hint: 'value 应为字符串或字符串数组' });
  if (typeof item.value === 'string' && item.value.trim() === '') fail('empty_value', { id: item.id });
  if (!item.source || !SOURCES.includes(item.source)) fail('invalid_source', { id: item.id, allowed: SOURCES });

  const change = {
    id: field.id, label: field.label,
    old_value: field.value, old_status: field.status, old_round: field.round, old_source: field.source,
    new_value: item.value, new_status: 'locked',
  };
  field.status = 'locked';
  field.value = item.value;
  field.round = round;
  field.source = item.source;

  ledger.header.current_round = round;
  ledger.header.last_locked = field.id;
  if (ledger.header.focus_field === field.id) ledger.header.focus_field = null;
  ledger.changelog.push({
    round, at: nowStamp(), kind: 'lock',
    action: change.old_status === 'locked' ? '修改' : '锁定',
    changes: [change],
    quote: args.quote ?? null,
  });
  saveLedger(args, ledger);
  out({ success: true, locked: field.id, round, progress: buildProgress(ledger) });
}

function buildProgress(ledger) {
  const fill = fillFields(ledger);
  const verify = verifyFields(ledger);
  const fillLocked = fill.filter((f) => f.status === 'locked').length;
  const verifyLocked = verify.filter((f) => f.status === 'locked').length;
  return {
    current_phase: ledger.header.phase,
    current_round: ledger.header.current_round,
    next_round: ledger.header.current_round + 1,
    fill: { locked: fillLocked, total: fill.length, complete: fillLocked === fill.length },
    verify: { locked: verifyLocked, total: verify.length, complete: verifyLocked === verify.length },
    focus_field: ledger.header.focus_field,
    sections: SECTIONS.map((s) => {
      const fs_ = ledger.fields.filter((f) => f.section === s.id);
      return { id: s.id, label: s.label, locked: fs_.filter((f) => f.status === 'locked').length, total: fs_.length };
    }),
  };
}

function cmdProgress(args) {
  out({ success: true, ...buildProgress(loadLedger(args)) });
}

function cmdStatus(args) {
  const ledger = loadLedger(args);
  out({
    success: true,
    header: ledger.header,
    fields: ledger.fields.map((f) => ({
      id: f.id, label: f.label, section: f.section, status: f.status,
      round: f.round, value: f.value, source: f.source,
    })),
  });
}

function cmdSummary(args) {
  const ledger = loadLedger(args);
  const locked = ledger.fields.filter((f) => f.status === 'locked');
  out({
    success: true,
    product_name: ledger.header.product_name,
    slug: ledger.header.slug,
    phase: ledger.header.phase,
    locked_fields: locked.map((f) => ({
      id: f.id, label: f.label,
      section: SECTIONS.find((s) => s.id === f.section)?.label,
      value: f.value, source: f.source, round: f.round,
    })),
    open_count: ledger.fields.length - locked.length,
  });
}

function cmdSetPhase(args) {
  const ledger = loadLedger(args);
  const round = Number(args.round);
  if (!Number.isInteger(round) || round < 0) fail('invalid_round', { hint: '--round 必须是 >=0 的整数' });
  const target = args.phase;
  const from = ledger.header.phase;
  const allowed = PHASE_TRANSITIONS[from] ?? [];
  if (!allowed.includes(target)) {
    fail('invalid_transition', { from_phase: from, target, allowed_targets: allowed,
      hint: target === 'DONE' ? 'DONE 仅由 save-canvas 触发' : undefined });
  }
  const p = buildProgress(ledger);
  if (from === 'FILL' && target === 'VERIFY' && !p.fill.complete) {
    fail('fields_incomplete', { fill: p.fill, hint: '21 个填写格未锁满，继续 FILL' });
  }
  if (from === 'VERIFY' && target === 'CONFIRM' && !p.verify.complete) {
    fail('fields_incomplete', { verify: p.verify, hint: '验证四问未锁满，继续 VERIFY' });
  }
  ledger.header.phase = target;
  ledger.header.focus_field = null;
  ledger.header.current_round = Math.max(ledger.header.current_round, round);
  saveLedger(args, ledger);
  out({ success: true, phase: target, round: ledger.header.current_round });
}

function cmdRollback(args) {
  const ledger = loadLedger(args);
  const last = [...ledger.changelog].reverse().find((e) => e.kind === 'lock');
  if (!last) fail('nothing_to_rollback');
  const round = ledger.header.current_round + 1;
  const changes = [];
  for (const c of last.changes) {
    const field = ledger.fields.find((f) => f.id === c.id);
    changes.push({
      id: field.id, label: field.label,
      old_value: field.value, old_status: field.status,
      new_value: c.old_value, new_status: c.old_status,
    });
    field.value = c.old_value;
    field.status = c.old_status;
    field.round = c.old_round;
    field.source = c.old_source;
  }
  ledger.header.current_round = round;
  ledger.header.last_locked = null;
  ledger.changelog.push({ round, at: nowStamp(), kind: 'rollback', action: `回滚 Round ${last.round}`, changes });
  saveLedger(args, ledger);
  out({ success: true, rolled_back_round: last.round, round });
}

function cmdRender(args) {
  const ledger = loadLedger(args);
  saveLedger(args, ledger);
  const dir = path.dirname(args.ledger);
  out({
    success: true,
    markdown: path.resolve(path.join(dir, `canvas-ledger-${ledger.header.slug}.md`)),
    html: path.resolve(path.join(dir, `canvas-${ledger.header.slug}.html`)),
  });
}

function cmdSaveCanvas(args) {
  const ledger = loadLedger(args);
  if (ledger.header.phase !== 'CONFIRM') fail('phase_guard', { from_phase: ledger.header.phase, hint: '仅 CONFIRM 阶段可落盘终稿' });
  const open = ledger.fields.filter((f) => f.status !== 'locked');
  if (open.length > 0) fail('fields_incomplete', { open_fields: open.map((f) => f.id) });
  if (!args.content) fail('missing_arg', { hint: '需要 --content <草稿路径>' });
  if (!fs.existsSync(args.content)) fail('file_not_found', { path: args.content });
  if (!args['output-dir']) fail('missing_arg', { hint: '需要 --output-dir <dir>' });

  const content = fs.readFileSync(args.content, 'utf8');
  const problems = [];
  if (!content.includes('# 创新画布:')) problems.push('缺少头部标题 "# 创新画布: <产品名称>"');
  if (!content.includes(`project_slug: ${ledger.header.slug}`)) problems.push(`头部缺少 "project_slug: ${ledger.header.slug}"`);
  const requiredHeadings = [
    '## 0. 画布一页总览',
    '## 1. 产品基础信息',
    '## 2. 需求',
    '## 3. 方案',
    '## 4. 增长',
    '## 5. 竞争',
    '## 6. 财务',
    '## 7. 验证',
    '## 附录',
  ];
  for (const heading of requiredHeadings) {
    if (!content.includes(heading)) problems.push(`缺少章节 "${heading}"`);
  }
  if (problems.length > 0) fail('structure_invalid', { problems });

  fs.mkdirSync(args['output-dir'], { recursive: true });
  const finalPath = path.join(args['output-dir'], `CANVAS-${ledger.header.slug}-${fileStamp()}.md`);
  fs.writeFileSync(finalPath, content, 'utf8');
  const draftPath = path.join(args['output-dir'], `.canvas-draft-${ledger.header.slug}.md`);
  if (path.resolve(args.content) === path.resolve(draftPath) && fs.existsSync(draftPath)) {
    fs.unlinkSync(draftPath);
  }
  ledger.header.phase = 'DONE';
  ledger.header.focus_field = null;
  ledger.header.last_locked = null;
  saveLedger(args, ledger);
  out({
    success: true,
    path: path.resolve(finalPath),
    html: path.resolve(path.join(args['output-dir'], `canvas-${ledger.header.slug}.html`)),
    phase: 'DONE',
  });
}

// ---------------------------------------------------------------------------
// 入口
// ---------------------------------------------------------------------------

const [, , command, ...rest] = process.argv;
const args = parseArgs(rest);

const COMMANDS = {
  'init': cmdInit,
  'next': cmdNext,
  'focus': cmdFocus,
  'lock': cmdLock,
  'set-phase': cmdSetPhase,
  'rollback': cmdRollback,
  'progress': cmdProgress,
  'status': cmdStatus,
  'summary': cmdSummary,
  'render': cmdRender,
  'save-canvas': cmdSaveCanvas,
};

if (!command || !COMMANDS[command]) {
  fail('unknown_command', { command: command ?? null, allowed: Object.keys(COMMANDS) });
}
COMMANDS[command](args);
