/**
 * canvas-smoke.test.mjs — canvas-writer 行为锁定测试
 *
 * 覆盖：init、分区顺序硬校验、focus 高亮、HTML 实时渲染内容、
 * FILL/VERIFY 阶段字段隔离、阶段转移业务规则、终稿结构校验与落盘、回滚。
 *
 * 运行：node --test canvas-writer/scripts/canvas-smoke.test.mjs
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const CLI = path.join(path.dirname(fileURLToPath(import.meta.url)), 'canvas-cli.mjs');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'canvas-writer-test-'));
const workDir = path.join(tmp, 'docs', 'canvas', 'pet-fresh-food');
const ledgerPath = path.join(workDir, 'ledger-state-pet-fresh-food.json');
const htmlPath = path.join(workDir, 'canvas-pet-fresh-food.html');

function run(cmd, args = []) {
  const res = spawnSync('node', [CLI, cmd, ...args], { encoding: 'utf8' });
  try {
    return JSON.parse(res.stdout);
  } catch {
    throw new Error(`CLI 输出不是 JSON: cmd=${cmd}\nstdout=${res.stdout}\nstderr=${res.stderr}`);
  }
}

function writeJson(name, data) {
  const p = path.join(tmp, name);
  fs.writeFileSync(p, JSON.stringify(data), 'utf8');
  return p;
}

function lock(id, value, source, round) {
  const f = writeJson(`lock-${id}-${round}.json`, [{ id, value, source }]);
  return run('lock', ['--ledger', ledgerPath, '--fields-file', f, '--round', String(round)]);
}

const FILL_ORDER = [
  'product_goal', 'product_metrics', 'schedule',
  'user_profile', 'demand_scenario', 'user_task',
  'value_proposition', 'key_business', 'core_resources', 'internal_partners', 'external_partners',
  'user_connection', 'user_success', 'relationship_growth',
  'diff_advantage', 'production_advantage', 'growth_advantage',
  'ltv', 'revenue_structure', 'cost_structure',
];
const VERIFY_ORDER = ['v_market', 'v_useful', 'v_feasible', 'v_cac'];

// ---------------------------------------------------------------------------

test('init: 创建台账，product_name round=0 锁定，生成 Markdown 与 HTML', () => {
  const r = run('init', ['--slug', 'pet-fresh-food', '--product-name', '喵鲜盒——给猫的新鲜每一天', '--output-dir', workDir]);
  assert.equal(r.success, true);
  assert.ok(fs.existsSync(ledgerPath));
  assert.ok(fs.existsSync(htmlPath));
  assert.ok(fs.existsSync(path.join(workDir, 'canvas-ledger-pet-fresh-food.md')));

  const ledger = JSON.parse(fs.readFileSync(ledgerPath, 'utf8'));
  assert.equal(ledger.header.phase, 'FILL');
  const name = ledger.fields.find((f) => f.id === 'product_name');
  assert.equal(name.status, 'locked');
  assert.equal(name.round, 0);
  assert.equal(ledger.fields.length, 25);
});

test('HTML: 未填格子展示 PPT 引导问题，自动刷新已开启', () => {
  const html = fs.readFileSync(htmlPath, 'utf8');
  assert.ok(html.includes('http-equiv="refresh"'), '进行中的画布应有自动刷新');
  assert.ok(html.includes('罗列至少 10 个'), '空格子应展示 PPT 引导问题');
  assert.ok(html.includes('LTV = LT × ARPU'), '财务格应展示 PPT 公式');
  assert.ok(html.includes('喵鲜盒'), '已填的产品名称应显示');
});

test('next: 首个待填格是 product_goal；跳分区锁定被拒绝', () => {
  const n = run('next', ['--ledger', ledgerPath]);
  assert.equal(n.next_field.id, 'product_goal');
  assert.ok(n.next_field.questions.length > 0);

  const skip = lock('user_profile', '跳过基础信息直接填需求', '需求方口述', 1);
  assert.equal(skip.success, false);
  assert.equal(skip.error, 'section_order');
  assert.equal(skip.expected, 'product_goal');
});

test('focus: HTML 中高亮当前格子并标注"正在咨询"', () => {
  const r = run('focus', ['--ledger', ledgerPath, '--field', 'product_goal']);
  assert.equal(r.success, true);
  const html = fs.readFileSync(htmlPath, 'utf8');
  assert.ok(html.includes('正在咨询'));
  assert.ok(html.match(/id="cell-product_goal"[^>]*/) || html.includes('cell focus') || html.includes('focus'), '焦点格应有 focus 样式');
  assert.ok(/class="cell open focus"[^>]*id="cell-product_goal"|id="cell-product_goal"/.test(html));
});

test('FILL: 阶段字段隔离（验证四问不可锁）；一次锁多个被拒', () => {
  const v = lock('v_market', '市场很大', '需求方口述', 1);
  assert.equal(v.success, false);
  assert.equal(v.error, 'phase_field_mismatch');

  const multi = writeJson('multi.json', [
    { id: 'product_goal', value: 'a', source: '需求方口述' },
    { id: 'schedule', value: 'b', source: '需求方口述' },
  ]);
  const m = run('lock', ['--ledger', ledgerPath, '--fields-file', multi, '--round', '1']);
  assert.equal(m.success, false);
  assert.equal(m.error, 'single_field_only');

  const badSource = lock('product_goal', '打开市场', '拍脑袋', 1);
  assert.equal(badSource.success, false);
  assert.equal(badSource.error, 'invalid_source');
});

test('FILL: 按 next 顺序填满 20 格，锁定后 HTML 实时更新', () => {
  let round = 1;
  for (const id of FILL_ORDER) {
    const n = run('next', ['--ledger', ledgerPath]);
    assert.equal(n.next_field.id, id, `next 应给出 ${id}，实际 ${n.next_field?.id}`);
    run('focus', ['--ledger', ledgerPath, '--field', id]);
    const r = lock(id, `【${id}】的确认内容`, id === 'ltv' ? '估算' : '需求方口述', round);
    assert.equal(r.success, true, `lock ${id} 失败: ${JSON.stringify(r)}`);
    round++;
  }
  const p = run('progress', ['--ledger', ledgerPath]);
  assert.equal(p.fill.complete, true);
  assert.equal(p.verify.complete, false);

  const html = fs.readFileSync(htmlPath, 'utf8');
  assert.ok(html.includes('【cost_structure】的确认内容'), '已填格子的内容应出现在 HTML 中');
});

test('阶段转移: FILL→VERIFY；VERIFY 只能锁验证四问且按顺序；VERIFY→CONFIRM 需锁满', () => {
  assert.equal(run('set-phase', ['--ledger', ledgerPath, '--phase', 'VERIFY', '--round', '21']).success, true);

  const fillInVerify = lock('product_goal2', 'x', '需求方口述', 22);
  assert.equal(fillInVerify.success, false);

  const wrongField = lock('user_profile', '想改画像', '需求方口述', 22);
  assert.equal(wrongField.success, false);
  assert.equal(wrongField.error, 'phase_field_mismatch');

  const early = run('set-phase', ['--ledger', ledgerPath, '--phase', 'CONFIRM', '--round', '22']);
  assert.equal(early.success, false);
  assert.equal(early.error, 'fields_incomplete');

  let round = 22;
  for (const id of VERIFY_ORDER) {
    const n = run('next', ['--ledger', ledgerPath]);
    assert.equal(n.next_field.id, id);
    const r = lock(id, `结论：成立。依据：画布相关格子。验证手段：${id === 'v_useful' ? '预售测试（待验证）' : '用户访谈（已验证）'}`, '需求方口述', round);
    assert.equal(r.success, true);
    round++;
  }
  assert.equal(run('set-phase', ['--ledger', ledgerPath, '--phase', 'CONFIRM', '--round', String(round)]).success, true);
});

test('save-canvas: 结构不合格拒绝；合格后落盘 DONE、草稿删除、HTML 完成态', () => {
  const draftPath = path.join(workDir, '.canvas-draft-pet-fresh-food.md');
  fs.writeFileSync(draftPath, '# 创新画布: 喵鲜盒\n只有头部\n', 'utf8');
  const bad = run('save-canvas', ['--ledger', ledgerPath, '--content', draftPath, '--output-dir', workDir]);
  assert.equal(bad.success, false);
  assert.equal(bad.error, 'structure_invalid');

  const good = [
    '# 创新画布: 喵鲜盒——给猫的新鲜每一天', '',
    '> project_slug: pet-fresh-food', '> 生成时间: 2026-07-27 18:30', '> Skill: canvas-writer', '',
    '## 0. 画布一页总览', '（表格）', '',
    '## 1. 产品基础信息', '…', '## 2. 需求（为谁设计）', '…',
    '## 3. 方案（以什么方式生产）', '…', '## 4. 增长（以什么方式规模化）', '…',
    '## 5. 竞争', '…', '## 6. 财务', '…', '## 7. 验证', '…', '',
    '## 附录', '…', '',
  ].join('\n');
  fs.writeFileSync(draftPath, good, 'utf8');
  const r = run('save-canvas', ['--ledger', ledgerPath, '--content', draftPath, '--output-dir', workDir]);
  assert.equal(r.success, true, JSON.stringify(r));
  assert.ok(fs.existsSync(r.path));
  assert.ok(!fs.existsSync(draftPath), '草稿应在落盘成功后删除');
  assert.equal(JSON.parse(fs.readFileSync(ledgerPath, 'utf8')).header.phase, 'DONE');

  const html = fs.readFileSync(htmlPath, 'utf8');
  assert.ok(html.includes('画布已完成'));
  assert.ok(!html.includes('http-equiv="refresh"'), '完成后停止自动刷新');
});

test('DONE→FILL reopen 修改后 rollback 恢复', () => {
  assert.equal(run('set-phase', ['--ledger', ledgerPath, '--phase', 'FILL', '--round', '27']).success, true);
  const r = lock('product_goal', '改为先做单城验证', '需求方口述', 28);
  assert.equal(r.success, true);
  const rb = run('rollback', ['--ledger', ledgerPath]);
  assert.equal(rb.success, true);
  const s = run('status', ['--ledger', ledgerPath]);
  assert.equal(s.fields.find((f) => f.id === 'product_goal').value, '【product_goal】的确认内容');
});

test('set-phase: 手动 DONE 被拒绝', () => {
  const r = run('set-phase', ['--ledger', ledgerPath, '--phase', 'DONE', '--round', '29']);
  assert.equal(r.success, false);
  assert.equal(r.error, 'invalid_transition');
});
