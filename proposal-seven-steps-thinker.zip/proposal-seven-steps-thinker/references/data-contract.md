# Data Contract（导出数据契约）

> 准备 `data.json` 供 `scripts/export_ppt.py` 和 `scripts/export_markdown.py` 使用。脚本对缺失字段宽容，但数据越好产出越好。

## 1. 最小结构

```json
{
  "title": "报告标题",
  "subtitle": "副标题",
  "date": "2026-05-16",
  "problem_statement": {},
  "logic_tree": {},
  "priority_matrix": {},
  "work_plan": [],
  "pyramid": {},
  "elevator_pitch": {},
  "storyboard": [],
  "interaction_log": []
}
```

## 2. 全字段参考

**顶层**：`title`(string, recommended)、`subtitle`(optional)、`date`(optional)、`problem_statement`(object, recommended)、`logic_tree`(object, recommended)、`priority_matrix`(object, recommended)、`work_plan`(array, recommended)、`pyramid`(object, recommended)、`elevator_pitch`(object, recommended)、`storyboard`(array, recommended)、`interaction_log`(array, optional)。

**problem_statement**：`core_problem`、`background`、`stakeholders`、`success_criteria`、`scope`、`constraints`、`smart_s/m/a/r/t`（值如"通过/待补"）。

**logic_tree**：`root`（核心问题）、`branches`（数组，每项含 `name` 和 `children` 字符串列表）、`mece_exclusive`、`mece_exhaustive`。

> 注意：branches 项可选含 `logic` 字段（分解逻辑说明，export_markdown 的逻辑树文档会引用）。

**priority_matrix**：`priority`（高影响×高可行）、`quick_win`（低影响×高可行）、`plan`（高影响×低可行）、`shelve`（低影响×低可行），均为字符串数组。

**work_plan**：数组，每项可同时含 Step 4 规划字段与 Step 5 分析字段：`issue`、`hypothesis`、`support`（或 `supporting_evidence`）、`method`、`required_info`、`source`（或 `data_source`）、`owner`、`start`、`deadline`、`deliverable`、`conclusion`、`status`。

> 字段名兼容：export_ppt 用 `support`；export_markdown 用 `supporting_evidence`/`data_source`。两套字段名都要容忍。

**pyramid**：`central_idea`、`mainlines`（数组，每项含 `title` 和 `evidence` 字符串列表）。

**elevator_pitch**：`audience`、`core_conclusion`、`key_findings`（字符串数组）、`next_action`。

**storyboard**：数组，每项含 `title`（结论式标题）、`content_type`（背景/问题/分析/结论/计划）、`chart_type`（图表建议）、`notes`（讲法备注）。

**interaction_log**：数组，每项含 `role`（user/ai）、`step`（如"Step 1"）、`content`、`timestamp`。

## 3. 导出准备规则

- 字段未知用空字符串或省略，不编造。
- 基于假设的结论在字段中写明为假设。
- 表格用短字符串，长证据放进 interaction_log 或 notes。
- `branches[].children` 保持字符串列表以兼容当前脚本。
- `work_plan` 保持扁平列表，不嵌套子项目（除非脚本已更新）。

## 4. 完整示例（AI 组织转型，摘要）

见 `assets/ai_org_transform_demo_data.json`。核心字段示例值：

- title："AI组织能力建设方案演练"，subtitle："基于七步成诗法的结构化方案梳理"，date："2026-04-27"
- problem_statement.core_problem："面向管理层评审会，在未来12个月内，建立业务团队使用AI的组织机制、方法体系和角色分工，为核心场景常规运行奠定基础。"
- logic_tree 4 个 branches：协同边界与运行机制是否清晰 / 方法体系是否可复制 / 先锋团队的角色与责任是否明确 / 常规运行标准是否明确（每项含 logic 和 children）
- priority_matrix.priority：["方法体系是否可复制","常规运行标准是否明确"]，quick_win：["先锋团队的角色与责任是否明确"]，plan：["协同边界与运行机制是否清晰"]
- work_plan 4 项（含 hypothesis/supporting_evidence/required_info/data_source/conclusion）
- pyramid.central_idea + 3 条 mainlines（各含 evidence 数组）
- elevator_pitch（audience/core_conclusion/key_findings/next_action）
- storyboard 9 项
- interaction_log 11 条用户交互记录
