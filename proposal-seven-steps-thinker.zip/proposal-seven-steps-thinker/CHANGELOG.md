# CHANGELOG

## 发布历史

### v1.3.1 — 2026-07-27

- owner 与版权归属由 Ivyliang 变更为 tingfeng（`SKILL.md` frontmatter 与版本权属摘要、`README.md`、`LICENSE.txt` 同步）。

### v1.3 — 2026-07-27

- 新增结构化提问约束：Step 1-7 的提问必须调用宿主 agent 的结构化提问工具（多问题表单一轮问完、每项给默认选项），严禁在聊天正文罗列编号问题清单；宿主确实没有提问工具时才允许一句话合并追问；
- 更新 `SKILL.md` 角色行为准则与版本元数据；
- 更新 `references/step-workflows.md` 全局节奏；
- 更新 `README.md` 版本摘要。

### v1.2 — 2026-05-18

- 新增根级 `CHANGELOG.md`；
- 把详细发布历史从 `SKILL.md` 移出，让根 skill 文件聚焦触发/角色/工作流/路由；
- 更新 `SKILL.md` 版本元数据与权属段落指向 `LICENSE.txt` 和 `CHANGELOG.md`；
- 更新 `README.md` 文件结构与版本摘要包含 `CHANGELOG.md`。

### v1.1 — 2026-05-16

- 根文件重构为紧凑路由器和执行契约；
- 详细 step workflow / templates / review rubric / 导出数据契约移入 `references/`；
- 新增 bundled 导出脚本与示例数据路由。

### v1.0 — 2026-05-12

- 补充 skill 包的版本与 owner 元数据。

## 版本管理规则

- patch（如 v1.2.1）：错别字、文案、小幅触发描述改进。
- minor（如 v1.3）：增加治理文件、references、模板、导出行为或不改变七步基础方法的工作流改进。
- major（如 v2.0）：引导工作流、状态模型、预期输出或用户交互契约发生不兼容变化。

每次实质变更需更新：`SKILL.md` frontmatter `version` → `SKILL.md` 版本与权属摘要 → CHANGELOG 最新 entry → README（仅当文件结构/边界/面向用户的能力变化时）。

## 发布更新清单

- [ ] 判断 patch / minor / major
- [ ] 更新 frontmatter version
- [ ] 更新版本与权属摘要
- [ ] 加 changelog entry
- [ ] 保持 release notes 事实化、行为导向
- [ ] 确认 `SKILL.md` 仍是路由器而非历史仓库
