#!/usr/bin/env python3
"""export_ppt.py — 生成"演示大纲" Markdown（历史名 ppt，实为 MD，9 个 Slide）。

为历史兼容保留文件名：曾计划生成 PPT，实际输出为可直接转 PPT 的
Markdown 演示大纲（非 PPT 二进制），无外部 PPT 引擎依赖。
仅使用标准库：os / json / argparse / datetime。
"""

import argparse
import json
import os
from datetime import datetime


def normalize_output_path(p):
    """非 .md 扩展名 → 改为 .md。"""
    base, ext = os.path.splitext(p)
    if ext.lower() != ".md":
        return base + ".md"
    return p


def safe_list(v):
    """非列表返回空列表；列表项转字符串 strip 后过滤空。"""
    if not isinstance(v, list):
        return []
    return [str(x).strip() for x in v if str(x).strip()]


def safe_text(v, default="待补充"):
    """None 或空 → default。"""
    if v is None:
        return default
    s = str(v).strip()
    return s if s else default


def bullets(items, empty_text="待补充"):
    """空则 `- {empty_text}`；否则每项 `- {item}`。"""
    items = safe_list(items)
    if not items:
        return "- {}".format(empty_text)
    return "\n".join("- {}".format(x) for x in items)


def _indented_bullets(items, empty_text="待补充", indent="  "):
    """bullets 的缩进版本，用于象限/分组列表。"""
    items = safe_list(items)
    if not items:
        return indent + "- {}".format(empty_text)
    return "\n".join(indent + "- {}".format(x) for x in items)


def build_cover(data):
    """封面：# {title} + > {subtitle} + > 日期：{date}（date 缺失取当天）。"""
    title = safe_text(data.get("title"), "团队方案演示大纲")
    subtitle = safe_text(data.get("subtitle"), "基于七步成诗法的结构化方案梳理")
    date = safe_text(data.get("date"), datetime.now().strftime("%Y-%m-%d"))
    return "# {}\n\n> {}\n>\n> 日期：{}\n".format(title, subtitle, date)


def build_toc():
    """Slide 1：固定 7 项目录。"""
    return (
        "## Slide 1｜目录\n"
        "- 1. 核心问题与背景\n"
        "- 2. 问题分解框架\n"
        "- 3. 优先级判断\n"
        "- 4. 工作计划\n"
        "- 5. 关键分析\n"
        "- 6. 结论与建议\n"
        "- 7. 汇报表达与下一步\n"
    )


def build_problem_statement(data):
    """Slide 2：问题陈述 6 字段 + 讲法建议。"""
    ps = data.get("problem_statement") or {}
    return (
        "## Slide 2｜核心问题与背景\n"
        "- 核心问题：{}\n".format(safe_text(ps.get("core_problem")))
        + "- 现状/背景：{}\n".format(safe_text(ps.get("background")))
        + "- 决策者与相关方：{}\n".format(safe_text(ps.get("stakeholders")))
        + "- 成功标准：{}\n".format(safe_text(ps.get("success_criteria")))
        + "- 方案范围：{}\n".format(safe_text(ps.get("scope")))
        + "- 限制因素：{}\n".format(safe_text(ps.get("constraints")))
        + "> 讲法建议：先说明为什么现在必须解决，再说明这次方案具体要回答什么问题。\n"
    )


def build_logic_tree(data):
    """Slide 3：根 + 分支（含 children 缩进）+ 独立性/穷尽性检查 + 讲法建议。"""
    lt = data.get("logic_tree") or {}
    lines = [
        "## Slide 3｜问题分解框架",
        "- 核心问题：{}".format(safe_text(lt.get("root"))),
        "- 逻辑树分解：",
    ]
    branches = lt.get("branches")
    if isinstance(branches, list) and branches:
        for b in branches:
            if not isinstance(b, dict):
                continue
            lines.append("  - {}：".format(safe_text(b.get("name"))))
            for c in safe_list(b.get("children")):
                lines.append("    - {}".format(c))
    else:
        lines.append("  - 待补充")
    lines.append("- 独立性检查：{}".format(safe_text(lt.get("mece_exclusive"))))
    lines.append("- 穷尽性检查：{}".format(safe_text(lt.get("mece_exhaustive"))))
    lines.append("> 讲法建议：先讲拆解维度，再讲为什么这些维度基本覆盖了问题全貌。")
    return "\n".join(lines) + "\n"


def build_priority_matrix(data):
    """Slide 4：四象限 bullets + 讲法建议。"""
    pm = data.get("priority_matrix") or {}
    return (
        "## Slide 4｜优先级判断\n\n"
        "- 高影响 × 高可行（优先处理）：\n"
        + _indented_bullets(pm.get("priority"))
        + "\n- 低影响 × 高可行（快速解决）：\n"
        + _indented_bullets(pm.get("quick_win"))
        + "\n- 高影响 × 低可行（重点规划）：\n"
        + _indented_bullets(pm.get("plan"))
        + "\n- 低影响 × 低可行（暂时搁置）：\n"
        + _indented_bullets(pm.get("shelve"))
        + "\n\n> 讲法建议：评审最关心的是为什么先做这些，而不是为什么没把所有事都做完。\n"
    )


def build_work_plan(data):
    """Slide 5：工作计划表 + 讲法建议；空时填"待补充/待定"行。"""
    wp = data.get("work_plan")
    lines = [
        "## Slide 5｜工作计划",
        "",
        "| 议题 | 负责人 | 分析方法 | 截止时间 | 预期成果 |",
        "| --- | --- | --- | --- | --- |",
    ]
    if isinstance(wp, list) and wp:
        for item in wp:
            if not isinstance(item, dict):
                continue
            lines.append(
                "| {} | {} | {} | {} | {} |".format(
                    safe_text(item.get("issue")),
                    safe_text(item.get("owner"), "待定"),
                    safe_text(item.get("method")),
                    safe_text(item.get("deadline"), "待定"),
                    safe_text(item.get("deliverable")),
                )
            )
    else:
        lines.append("| 待补充 | 待定 | 待补充 | 待定 | 待补充 |")
    lines.append("")
    lines.append("> 讲法建议：这一页不要只列任务，要强调责任、节奏和交付物。")
    return "\n".join(lines) + "\n"


def build_key_analysis(data):
    """Slide 6：遍历 work_plan，每议题 初始假设/验证方式/分析结论 + 讲法建议。"""
    wp = data.get("work_plan")
    lines = ["## Slide 6｜关键分析", ""]
    items = [x for x in wp if isinstance(x, dict)] if isinstance(wp, list) else []
    if items:
        for item in items:
            lines.append("### 议题：{}".format(safe_text(item.get("issue"))))
            lines.append("")
            lines.append("- 初始假设：{}".format(safe_text(item.get("hypothesis"))))
            lines.append("- 验证方式：{}".format(safe_text(item.get("method"))))
            lines.append("- 分析结论：{}".format(safe_text(item.get("conclusion"), "待分析")))
            lines.append("")
    else:
        lines.append("### 议题：待补充")
        lines.append("")
        lines.append("- 初始假设：待补充")
        lines.append("- 验证方式：待补充")
        lines.append("- 分析结论：待分析")
        lines.append("")
    lines.append("> 讲法建议：先讲证据，再讲判断，不要只给结论不给依据。")
    return "\n".join(lines) + "\n"


def build_pyramid(data):
    """Slide 7：中心思想 + 主线（含论据）+ 讲法建议。"""
    py = data.get("pyramid") or {}
    lines = [
        "## Slide 7｜结论与建议（金字塔）",
        "",
        "- 中心思想：{}".format(safe_text(py.get("central_idea"))),
        "- 三条主线：",
    ]
    mainlines = py.get("mainlines")
    items = [m for m in mainlines if isinstance(m, dict)] if isinstance(mainlines, list) else []
    if items:
        for idx, m in enumerate(items, 1):
            lines.append("    - 主线 {}：{}".format(idx, safe_text(m.get("title"))))
            for e in safe_list(m.get("evidence")):
                lines.append("        - 论据：{}".format(e))
    else:
        lines.append("    - 主线 1：待补充")
    lines.append("")
    lines.append('> 讲法建议：这一页必须回答"所以呢"，让评审能快速抓住最终判断。')
    return "\n".join(lines) + "\n"


def build_elevator_pitch(data):
    """Slide 8：汇报对象/核心结论/关键发现 bullets/建议行动 + 讲法建议。"""
    ep = data.get("elevator_pitch") or {}
    lines = [
        "## Slide 8｜30 秒汇报表达",
        "",
        "- 汇报对象：{}".format(safe_text(ep.get("audience"), "决策者")),
        "- 核心结论：{}".format(safe_text(ep.get("core_conclusion"))),
        "- 关键发现：",
        _indented_bullets(ep.get("key_findings")),
        "- 建议行动：{}".format(safe_text(ep.get("next_action"))),
        "",
        "> 讲法建议：压缩到 30 秒内能讲清主结论、三点依据和下一步动作。",
    ]
    return "\n".join(lines) + "\n"


def build_storyboard(data):
    """Slide 9：故事板表 + 用法建议。"""
    sb = data.get("storyboard")
    lines = [
        "## Slide 9｜完整故事板",
        "",
        "| 页码 | 标题 | 内容类型 | 图表建议 |",
        "| --- | --- | --- | --- |",
    ]
    items = [s for s in sb if isinstance(s, dict)] if isinstance(sb, list) else []
    if items:
        for idx, s in enumerate(items, 1):
            lines.append(
                "| {} | {} | {} | {} |".format(
                    idx,
                    safe_text(s.get("title")),
                    safe_text(s.get("content_type")),
                    safe_text(s.get("chart_type")),
                )
            )
    else:
        lines.append("| 1 | 待补充 | 待补充 | 待补充 |")
    lines.append("")
    lines.append("> 用法建议：可直接把这一节逐页搬进 PPT，每行对应一页。")
    return "\n".join(lines) + "\n"


def build_footer():
    """页脚占位：返回空字符串。"""
    return ""


def generate_outline(data, output_path):
    """按顺序拼接各 section，makedirs，写 utf-8，返回路径。"""
    output_path = normalize_output_path(output_path)
    sections = [
        build_cover(data),
        build_toc(),
        build_problem_statement(data),
        build_logic_tree(data),
        build_priority_matrix(data),
        build_work_plan(data),
        build_key_analysis(data),
        build_pyramid(data),
        build_elevator_pitch(data),
        build_storyboard(data),
        build_footer(),
    ]
    content = "\n".join(s for s in sections if s)
    content = content.rstrip() + "\n\n---\n\n仅供内部讨论，请勿外传。\n"
    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)
    return output_path


def load_data(path):
    """存在则 json.load；否则返回默认 dict。"""
    if path and os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "title": "团队方案演示大纲",
        "subtitle": "基于七步成诗法的结构化方案梳理",
        "date": datetime.now().strftime("%Y-%m-%d"),
    }


def main():
    """argparse 解析，调用 generate_outline，打印成功信息。"""
    parser = argparse.ArgumentParser(
        description="生成七步成诗演示大纲 Markdown（历史名 export_ppt，实际输出 MD）。"
    )
    parser.add_argument(
        "--data", "-d", default=None,
        help="data.json 路径；缺失时使用内置默认数据。",
    )
    parser.add_argument(
        "--output", "-o", default="七步成诗演示大纲.md",
        help="输出 Markdown 路径；扩展名非 .md 时自动规范为 .md。",
    )
    args = parser.parse_args()
    data = load_data(args.data)
    path = generate_outline(data, args.output)
    print("演示大纲已生成：{}".format(path))


if __name__ == "__main__":
    main()
