#!/usr/bin/env python3
"""export_markdown.py — 导出 5 份结构化 Markdown。

产物：交互记录 / 问题陈述书 / 逻辑树 / 工作计划表 / 沟通故事板。
仅使用标准库：os / json / argparse / datetime。
"""

import argparse
import json
import os
from datetime import datetime


STEP_NAMES = [
    ("Step 1", "界定问题"),
    ("Step 2", "分解问题"),
    ("Step 3", "优先排序"),
    ("Step 4", "工作计划"),
    ("Step 5", "关键分析"),
    ("Step 6", "归纳建议"),
    ("Step 7", "交流沟通"),
]


def _now():
    """YYYY-MM-DD HH:MM。"""
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def safe_list(v):
    if not isinstance(v, list):
        return []
    return [str(x).strip() for x in v if str(x).strip()]


def safe_text(v, default="待补充"):
    if v is None:
        return default
    s = str(v).strip()
    return s if s else default


def _item_text(item, *keys, default="待填写"):
    """按字段名优先级取值（字段名兼容：supporting_evidence/support、data_source/source）。"""
    for k in keys:
        v = item.get(k)
        if v is not None and str(v).strip():
            return str(v).strip()
    return default


def _bullets(items, empty_text="无"):
    items = safe_list(items)
    if not items:
        return "- {}".format(empty_text)
    return "\n".join("- {}".format(x) for x in items)


def _write(path, content):
    out_dir = os.path.dirname(path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def _generate_summary_from_data(data):
    """无 interaction_log 时，从结构化数据按 Step 1-7 生成交互摘要。"""
    ps = data.get("problem_statement") or {}
    lt = data.get("logic_tree") or {}
    pm = data.get("priority_matrix") or {}
    wp = data.get("work_plan") if isinstance(data.get("work_plan"), list) else []
    py = data.get("pyramid") or {}
    ep = data.get("elevator_pitch") or {}

    parts = []

    parts.append(
        "### Step 1 · 界定问题\n"
        "- 核心问题：{}\n- 现状/背景：{}\n- 决策者与相关方：{}\n- 成功标准：{}".format(
            safe_text(ps.get("core_problem")),
            safe_text(ps.get("background")),
            safe_text(ps.get("stakeholders")),
            safe_text(ps.get("success_criteria")),
        )
    )

    tree_lines = ["### Step 2 · 分解问题", "- 核心问题：{}".format(safe_text(lt.get("root")))]
    branches = lt.get("branches")
    if isinstance(branches, list) and branches:
        for b in branches:
            if not isinstance(b, dict):
                continue
            tree_lines.append("- 分支：{}".format(safe_text(b.get("name"))))
            for c in safe_list(b.get("children")):
                tree_lines.append("  - {}".format(c))
    else:
        tree_lines.append("- 分支：待补充")
    parts.append("\n".join(tree_lines))

    parts.append(
        "### Step 3 · 优先排序\n"
        "- ⭐ 最高优先级：\n{}\n- 🟡 快速解决：\n{}\n- 🔵 重点规划：\n{}\n- ⚪ 暂时搁置：\n{}".format(
            _bullets(pm.get("priority"), "待补充"),
            _bullets(pm.get("quick_win"), "待补充"),
            _bullets(pm.get("plan"), "待补充"),
            _bullets(pm.get("shelve"), "待补充"),
        )
    )

    plan_lines = ["### Step 4 & 5 · 工作计划与关键分析"]
    if wp:
        for i, item in enumerate(wp, 1):
            if not isinstance(item, dict):
                continue
            plan_lines.append(
                "- {}. {}（负责人：{}，截止：{}）".format(
                    i,
                    safe_text(item.get("issue")),
                    safe_text(item.get("owner"), "待定"),
                    safe_text(item.get("deadline"), "待定"),
                )
            )
    else:
        plan_lines.append("- 待补充")
    parts.append("\n".join(plan_lines))

    py_lines = ["### Step 6 · 归纳建议", "- 中心思想：{}".format(safe_text(py.get("central_idea")))]
    mainlines = py.get("mainlines")
    if isinstance(mainlines, list) and mainlines:
        for m in mainlines:
            if not isinstance(m, dict):
                continue
            py_lines.append("- 主线：{}".format(safe_text(m.get("title"))))
            for e in safe_list(m.get("evidence")):
                py_lines.append("  - 论据：{}".format(e))
    else:
        py_lines.append("- 主线：待补充")
    parts.append("\n".join(py_lines))

    pitch_lines = [
        "### Step 7 · 交流沟通",
        "- 核心结论：{}".format(safe_text(ep.get("core_conclusion"))),
        "- 关键发现：",
    ]
    findings = safe_list(ep.get("key_findings"))
    if findings:
        pitch_lines.extend("  - {}".format(f) for f in findings)
    else:
        pitch_lines.append("  - 待补充")
    pitch_lines.append("- 下一步行动：{}".format(safe_text(ep.get("next_action"))))
    parts.append("\n".join(pitch_lines))

    return "\n\n".join(parts)


def export_interaction_log(data, output_dir, prefix):
    """导出 {prefix}_交互记录.md。"""
    log = data.get("interaction_log")
    lines = [
        "# {} — 交互记录".format(prefix),
        "> 生成时间：{}".format(_now()),
        "> 方法论：麦肯锡七步成诗法",
        "> 报告标题：{}".format(safe_text(data.get("title"), "（未命名）")),
        "",
        "---",
        "",
        "## 交互概要",
        "",
        "| 步骤 | 名称 | 状态 |",
        "| --- | --- | --- |",
    ]
    status = {
        "Step 1": bool(data.get("problem_statement")),
        "Step 2": bool(data.get("logic_tree")),
        "Step 3": bool(data.get("priority_matrix")),
        "Step 4": bool(data.get("work_plan")),
        "Step 5": bool(data.get("work_plan")),
        "Step 6": bool(data.get("pyramid")),
        "Step 7": bool(data.get("storyboard") or data.get("elevator_pitch")),
    }
    for step, name in STEP_NAMES:
        lines.append("| {} | {} | {} |".format(step, name, "✅" if status.get(step) else "待补充"))
    lines += ["", "---", "", "## 详细交互过程", ""]

    if isinstance(log, list) and log:
        prev_step = None
        for entry in log:
            if not isinstance(entry, dict):
                continue
            step = safe_text(entry.get("step"), "")
            if step and step != prev_step:
                lines.append("### {}".format(step))
                lines.append("")
                prev_step = step
            role = entry.get("role")
            label = "👤 用户" if role == "user" else "🤖 顾问"
            ts = safe_text(entry.get("timestamp"), "")
            head = "**{}**".format(label) + ("（{}）".format(ts) if ts else "")
            lines.append(head)
            lines.append("")
            lines.append(safe_text(entry.get("content"), ""))
            lines.append("")
            lines.append("---")
            lines.append("")
    else:
        lines.append(_generate_summary_from_data(data))
        lines.append("")
        lines.append("---")
        lines.append("")

    lines += [
        "## 成果文档",
        "",
        "| 格式 | 文件 |",
        "| --- | --- |",
        "| Markdown 演示大纲 | {}_七步成诗演示大纲.md |".format(prefix),
        "| Markdown 交互记录 | {}_交互记录.md |".format(prefix),
        "| Markdown 结构化文档 | {0}_问题陈述书.md / {0}_逻辑树.md / {0}_工作计划表.md / {0}_沟通故事板.md |".format(prefix),
        "",
        "> 本文档由七步成诗问题解决助手自动生成。",
        "",
    ]
    return _write(os.path.join(output_dir, "{}_交互记录.md".format(prefix)), "\n".join(lines))


def export_problem_statement(data, output_dir, prefix):
    """导出 {prefix}_问题陈述书.md。"""
    ps = data.get("problem_statement") or {}
    lines = [
        "# {} — 问题陈述书（Problem Statement）".format(prefix),
        "> 生成时间：{}".format(_now()),
        "> 方法论：麦肯锡七步成诗法 · Step 1",
        "",
        "---",
        "",
        "## 核心问题",
        "",
        safe_text(ps.get("core_problem")),
        "",
        "---",
        "",
        "## 1. 现状/背景",
        "",
        safe_text(ps.get("background")),
        "",
        "## 2. 决策者与相关方",
        "",
        safe_text(ps.get("stakeholders")),
        "",
        "## 3. 成功标准",
        "",
        safe_text(ps.get("success_criteria")),
        "",
        "## 4. 解决方案范围",
        "",
        safe_text(ps.get("scope")),
        "",
        "## 5. 限制因素",
        "",
        safe_text(ps.get("constraints")),
        "",
        "---",
        "",
        "## SMART 检查",
        "",
        "| 原则 | 检查项 | 状态 |",
        "| --- | --- | --- |",
        "| Specific（具体） | 问题是否足够具体？ | {} |".format(safe_text(ps.get("smart_s"), "✅")),
        "| Measurable（可衡量） | 成功标准是否可量化？ | {} |".format(safe_text(ps.get("smart_m"), "✅")),
        "| Actionable（可行动） | 是否以行动为导向？ | {} |".format(safe_text(ps.get("smart_a"), "✅")),
        "| Relevant（相关） | 与核心业务的关联？ | {} |".format(safe_text(ps.get("smart_r"), "✅")),
        "| Time-framed（有时限） | 是否有明确期限？ | {} |".format(safe_text(ps.get("smart_t"), "✅")),
        "",
    ]
    return _write(os.path.join(output_dir, "{}_问题陈述书.md".format(prefix)), "\n".join(lines))


def export_logic_tree(data, output_dir, prefix):
    """导出 {prefix}_逻辑树.md（用 ├/└/│ 字符画树）。"""
    lt = data.get("logic_tree") or {}
    branches = [b for b in lt.get("branches", []) if isinstance(b, dict)] if isinstance(lt.get("branches"), list) else []

    tree_lines = [safe_text(lt.get("root")), ""]
    for i, b in enumerate(branches):
        last_b = i == len(branches) - 1
        tree_lines.append(("└── " if last_b else "├── ") + safe_text(b.get("name")))
        children = safe_list(b.get("children"))
        pad = "    " if last_b else "│   "
        for j, c in enumerate(children):
            last_c = j == len(children) - 1
            tree_lines.append(pad + ("└── " if last_c else "├── ") + c)
        if not last_b:
            tree_lines.append("│")

    dim_lines = [
        "| 层级 | 议题 | 分解逻辑 | MECE 检查 |",
        "| --- | --- | --- | --- |",
    ]
    for b in branches:
        dim_lines.append(
            "| L1 | {} | {} | ✅ |".format(
                safe_text(b.get("name")), safe_text(b.get("logic"), "待说明")
            )
        )
        for c in safe_list(b.get("children")):
            dim_lines.append("| L2 | {} | — | ✅ |".format(c))

    lines = [
        "# {} — 逻辑树（Logic Tree）".format(prefix),
        "> 生成时间：{}".format(_now()),
        "> 方法论：麦肯锡七步成诗法 · Step 2",
        "> 核心原则：MECE（相互独立，完全穷尽）",
        "",
        "---",
        "",
        "## 问题分解结构",
        "",
        "```text",
        "\n".join(tree_lines),
        "```",
        "",
        "---",
        "",
        "## 分解维度说明",
        "",
    ] + dim_lines + [
        "",
        "---",
        "",
        "## MECE 验证总结",
        "",
        "### 相互独立性",
        "",
        safe_text(lt.get("mece_exclusive"), "所有子议题之间无概念重叠"),
        "",
        "### 完全穷尽性",
        "",
        safe_text(lt.get("mece_exhaustive"), "所有子议题合计覆盖了问题的全部方面"),
        "",
    ]
    return _write(os.path.join(output_dir, "{}_逻辑树.md".format(prefix)), "\n".join(lines))


def export_work_plan(data, output_dir, prefix):
    """导出 {prefix}_工作计划表.md。"""
    pm = data.get("priority_matrix") or {}
    wp = [x for x in data.get("work_plan", []) if isinstance(x, dict)] if isinstance(data.get("work_plan"), list) else []

    lines = [
        "# {} — 工作计划表".format(prefix),
        "> 生成时间：{}".format(_now()),
        "> 方法论：麦肯锡七步成诗法 · Step 3-5",
        "",
        "---",
        "",
        "## 优先级排序结果",
        "",
        "### ⭐ 最高优先级（高影响 × 高可行）",
        _bullets(pm.get("priority")),
        "",
        "### 🟡 快速解决（低影响 × 高可行）",
        _bullets(pm.get("quick_win")),
        "",
        "### 🔵 重点规划（高影响 × 低可行）",
        _bullets(pm.get("plan")),
        "",
        "### ⚪ 暂时搁置（低影响 × 低可行）",
        _bullets(pm.get("shelve")),
        "",
        "---",
        "",
        "## 综合工作计划表",
        "",
        "| 序号 | 议题 | 负责人 | 分析方法 | 截止时间 | 预期成果 | 状态 |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    for i, item in enumerate(wp, 1):
        lines.append(
            "| {} | {} | {} | {} | {} | {} | {} |".format(
                i,
                safe_text(item.get("issue")),
                safe_text(item.get("owner"), "待定"),
                safe_text(item.get("method"), "待定"),
                safe_text(item.get("deadline"), "待定"),
                safe_text(item.get("deliverable"), "待定"),
                safe_text(item.get("status"), "待启动"),
            )
        )
    if not wp:
        lines.append("| 1 | 待补充 | 待定 | 待定 | 待定 | 待定 | 待启动 |")

    lines += ["", "---", "", "## 议题分析工作表", ""]
    for i, item in enumerate(wp, 1):
        lines += [
            "### 议题 {}: {}".format(i, safe_text(item.get("issue"))),
            "",
            "| 维度 | 内容 |",
            "| --- | --- |",
            "| 初始假设 | {} |".format(_item_text(item, "hypothesis")),
            "| 支持依据 | {} |".format(_item_text(item, "supporting_evidence", "support")),
            "| 分析方法 | {} |".format(_item_text(item, "method")),
            "| 所需信息 | {} |".format(_item_text(item, "required_info")),
            "| 信息来源 | {} |".format(_item_text(item, "data_source", "source")),
            "| 负责人 | {} |".format(_item_text(item, "owner")),
            "| 时间节点 | {} |".format(_item_text(item, "deadline")),
            "| 预期成果 | {} |".format(_item_text(item, "deliverable")),
            "| 分析结论 | {} |".format(safe_text(item.get("conclusion"), "待分析")),
            "",
        ]
    if not wp:
        lines += [
            "### 议题 1: 待补充",
            "",
            "| 维度 | 内容 |",
            "| --- | --- |",
            "| 初始假设 | 待填写 |",
            "| 支持依据 | 待填写 |",
            "| 分析方法 | 待填写 |",
            "| 所需信息 | 待填写 |",
            "| 信息来源 | 待填写 |",
            "| 负责人 | 待填写 |",
            "| 时间节点 | 待填写 |",
            "| 预期成果 | 待填写 |",
            "| 分析结论 | 待分析 |",
            "",
        ]

    lines += [
        "## 工作计划自检清单",
        "",
        "- [ ] 目标和最终成果是否明确界定？",
        "- [ ] 所有分析是否都十分必要，是否充分回答了问题？",
        "- [ ] 下一步工作是否明确？分析是否切实可行？",
        "- [ ] 责任和时间要求是否明确？",
        "- [ ] 时间安排是否符合整体项目要求和重点？",
        "",
    ]
    return _write(os.path.join(output_dir, "{}_工作计划表.md".format(prefix)), "\n".join(lines))


def export_storyboard(data, output_dir, prefix):
    """导出 {prefix}_沟通故事板.md。"""
    py = data.get("pyramid") or {}
    ep = data.get("elevator_pitch") or {}
    sb = [s for s in data.get("storyboard", []) if isinstance(s, dict)] if isinstance(data.get("storyboard"), list) else []

    lines = [
        "# {} — 沟通故事板（Storyboard）".format(prefix),
        "> 生成时间：{}".format(_now()),
        "> 方法论：麦肯锡七步成诗法 · Step 6 & 7",
        "",
        "---",
        "",
        "## 金字塔结构",
        "",
        "### 中心思想",
        "",
        safe_text(py.get("central_idea")),
        "",
    ]
    mainlines = [m for m in py.get("mainlines", []) if isinstance(m, dict)] if isinstance(py.get("mainlines"), list) else []
    for i, m in enumerate(mainlines, 1):
        lines.append("### 主线 {}: {}".format(i, safe_text(m.get("title"))))
        lines.append("")
        for e in safe_list(m.get("evidence")):
            lines.append("- {}".format(e))
        lines.append("")
    if not mainlines:
        lines += ["### 主线 1: 待补充", "", "- 待补充", ""]

    audience = safe_text(ep.get("audience"), "决策者")
    lines += [
        "---",
        "",
        "## 30 秒电梯推销",
        "",
        "**沟通对象**：{}".format(audience),
        "",
        "> {}，关于我们的核心问题：".format(audience),
        "> **核心结论**：{}".format(safe_text(ep.get("core_conclusion"))),
        "> **关键发现**：",
    ]
    findings = safe_list(ep.get("key_findings"))
    if findings:
        for i, f in enumerate(findings, 1):
            lines.append("> {}. {}".format(i, f))
    else:
        lines.append("> 1. 待补充")
    lines += [
        "> **建议行动**：{}".format(safe_text(ep.get("next_action"))),
        "> ⏱️ 预计时长：25-30 秒",
        "",
        "---",
        "",
        "## 沟通故事板",
        "",
        "**故事线**：情境 → 冲突 → 疑问 → 回答",
        "",
        "| 页码 | 标题 | 内容类型 | 核心数据/图表 |",
        "| --- | --- | --- | --- |",
    ]
    for i, s in enumerate(sb, 1):
        lines.append(
            "| {} | {} | {} | {} |".format(
                i,
                safe_text(s.get("title")),
                safe_text(s.get("content_type")),
                safe_text(s.get("chart_type")),
            )
        )
    if not sb:
        lines.append("| 1 | 待补充 | 待补充 | 待补充 |")

    lines += [
        "",
        "---",
        "",
        "## 金字塔检查清单",
        "",
        "### 中心思想",
        "",
        "- [ ] 回答了决策者的关键问题",
        "- [ ] 是提炼而非信息罗列",
        "- [ ] 语言简洁准确",
        "",
        "### 主线",
        "",
        "- [ ] 紧密支持中心思想（MECE）",
        "- [ ] 面向行动/解决方案",
        "- [ ] 属于同一层次且逻辑排列",
        "",
        "### 支持论据",
        "",
        "- [ ] 相关、充分且基于事实",
        "- [ ] 充分支持上一层观点",
        "",
    ]
    return _write(os.path.join(output_dir, "{}_沟通故事板.md".format(prefix)), "\n".join(lines))


def export_all(data, output_dir, prefix):
    """依次调用 5 个导出函数，makedirs，打印进度，返回文件列表。"""
    os.makedirs(output_dir, exist_ok=True)
    files = [
        export_interaction_log(data, output_dir, prefix),
        export_problem_statement(data, output_dir, prefix),
        export_logic_tree(data, output_dir, prefix),
        export_work_plan(data, output_dir, prefix),
        export_storyboard(data, output_dir, prefix),
    ]
    for f in files:
        print("已生成：{}".format(f))
    return files


DEFAULT_DATA = {
    "title": "七步成诗方案演练（示例）",
    "subtitle": "基于七步成诗法的结构化方案梳理",
    "date": "",
    "problem_statement": {
        "core_problem": "示例核心问题：在明确时限内，针对指定业务场景达成可衡量的改善目标",
        "background": "示例背景：业务现状发生变化，需要在本次评审前形成结构化方案",
        "stakeholders": "示例决策者：业务负责人；关键相关方：评审组、执行团队",
        "success_criteria": "示例成功标准：关键指标在期限内达成约定水平",
        "scope": "包括：示例范围；不包括：示例排除项",
        "constraints": "示例限制：预算、人力、时间、数据权限",
        "smart_s": "✅",
        "smart_m": "✅",
        "smart_a": "✅",
        "smart_r": "✅",
        "smart_t": "✅",
    },
    "logic_tree": {
        "root": "示例核心问题",
        "branches": [
            {"name": "示例分支一", "logic": "示例分解逻辑", "children": ["示例子议题 1.1", "示例子议题 1.2"]},
            {"name": "示例分支二", "logic": "示例分解逻辑", "children": ["示例子议题 2.1", "示例子议题 2.2"]},
            {"name": "示例分支三", "logic": "示例分解逻辑", "children": ["示例子议题 3.1", "示例子议题 3.2"]},
        ],
        "mece_exclusive": "示例：各子议题之间无概念重叠",
        "mece_exhaustive": "示例：各子议题合计覆盖了问题的全部方面",
    },
    "priority_matrix": {
        "priority": ["示例优先议题"],
        "quick_win": ["示例快速解决议题"],
        "plan": ["示例重点规划议题"],
        "shelve": ["示例暂时搁置议题"],
    },
    "work_plan": [
        {
            "issue": "示例议题",
            "hypothesis": "示例初始假设",
            "supporting_evidence": "示例支持依据",
            "method": "示例分析方法",
            "required_info": "示例所需信息",
            "data_source": "示例信息来源",
            "owner": "待定",
            "deadline": "待定",
            "deliverable": "示例预期成果",
            "conclusion": "待分析",
            "status": "待启动",
        }
    ],
    "pyramid": {
        "central_idea": "示例中心思想：一句话回答核心问题",
        "mainlines": [
            {"title": "示例主线一", "evidence": ["示例论据 1", "示例论据 2"]},
            {"title": "示例主线二", "evidence": ["示例论据 1"]},
            {"title": "示例主线三", "evidence": ["示例论据 1"]},
        ],
    },
    "elevator_pitch": {
        "audience": "决策者",
        "core_conclusion": "示例核心结论",
        "key_findings": ["示例发现一", "示例发现二", "示例发现三"],
        "next_action": "示例下一步行动",
    },
    "storyboard": [
        {"title": "示例页标题 1", "content_type": "背景", "chart_type": "示例图表", "notes": ""},
        {"title": "示例页标题 2", "content_type": "问题", "chart_type": "示例图表", "notes": ""},
        {"title": "示例页标题 3", "content_type": "结论", "chart_type": "示例图表", "notes": ""},
    ],
    "interaction_log": [],
}


def load_data(path):
    if path and os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return DEFAULT_DATA


def main():
    parser = argparse.ArgumentParser(
        description="导出 5 份结构化 Markdown（交互记录/问题陈述书/逻辑树/工作计划表/沟通故事板）。"
    )
    parser.add_argument("--data", "-d", default=None, help="data.json 路径；缺失时使用内置示例数据。")
    parser.add_argument("--output-dir", "-o", default=".", help="输出目录，默认当前目录。")
    parser.add_argument("--prefix", "-p", default="七步成诗", help="输出文件名前缀，默认「七步成诗」。")
    parser.add_argument(
        "--type", "-t",
        choices=["all", "log", "statement", "tree", "plan", "storyboard"],
        default="all",
        help="导出类型，默认 all。",
    )
    args = parser.parse_args()
    data = load_data(args.data)

    dispatch = {
        "log": lambda: export_interaction_log(data, args.output_dir, args.prefix),
        "statement": lambda: export_problem_statement(data, args.output_dir, args.prefix),
        "tree": lambda: export_logic_tree(data, args.output_dir, args.prefix),
        "plan": lambda: export_work_plan(data, args.output_dir, args.prefix),
        "storyboard": lambda: export_storyboard(data, args.output_dir, args.prefix),
    }

    if args.type == "all":
        export_all(data, args.output_dir, args.prefix)
    else:
        path = dispatch[args.type]()
        print("已生成：{}".format(path))


if __name__ == "__main__":
    main()
