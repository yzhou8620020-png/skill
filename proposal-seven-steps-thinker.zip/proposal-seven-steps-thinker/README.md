# Proposal Seven Steps Thinker（七步成诗思考搭子）

在用户正式写方案/PPT/汇报前，先带他完成结构化问题解决过程的"思考搭子"。以咨询顾问 + 评审教练双重角色，把问题、逻辑、证据、建议、汇报表达逐步校准到能过评审的状态。

- Current version: v1.3.1（2026-07-27）
- Owner: tingfeng
- License: Internal skill asset，详见 `LICENSE.txt`；版本历史与版本规则详见 `CHANGELOG.md`。

## 适用场景

准备方案、提案、汇报、评审材料、项目复盘或复杂专项，且写作前需要先把问题想清楚：AI 组织转型、O2O 用户研究、用户流量运营、增长策略、经营诊断、跨部门专项等。

典型触发：

- "帮我用七步成诗梳理"
- "先别写 PPT，先帮我把问题想清楚"
- "评审总说逻辑不清"
- "帮我检查方案的问题定义、逻辑树和证据"

## 七步工作流

```text
Thinking mode:     Step 1 界定问题 → Step 2 分解问题 → Step 3 优先排序
Action mode:       Step 4 工作计划 → Step 5 关键分析 → Step 6 归纳建议
Communication mode: Step 7 交流沟通
```

工作流是迭代的：任一步发现早期假设错误，回到相关步骤重修。Step 1-3 与 Step 4 之间有思考→行动硬门；导出前有最终评审门。

## 文件结构

```text
proposal-seven-steps-thinker/
├── SKILL.md                      # 运行入口与路由器：触发、角色、状态机、流程契约、资源路由
├── README.md                     # 本文件
├── CHANGELOG.md                  # 版本历史 + 版本管理规则 + 发布更新清单
├── LICENSE.txt                   # 权属、授权范围、限制、方法论引用声明、免责
├── references/
│   ├── step-workflows.md         # Step 1-7 详细操作流程
│   ├── methodology.md            # 方法论详解与案例
│   ├── templates.md              # 输出模板
│   ├── review-rubric.md          # 评审质检
│   └── data-contract.md          # 导出脚本数据契约
├── scripts/
│   ├── export_ppt.py             # 生成"演示大纲" Markdown（历史名 ppt，实为 MD，9 个 Slide）
│   ├── export_markdown.py        # 生成 5 份结构化 Markdown
│   └── 七步成诗*.md              # 6 个脚本示例产物（展示输出格式，非模板源）
└── assets/
    └── ai_org_transform_demo_data.json   # 完整真实示例数据（AI 组织转型）
```

## 输出

七步完成后（或用户说"导出成果"）导出 6 份 Markdown：

1. `{问题简称}_七步成诗演示大纲.md`
2. `{问题简称}_交互记录.md`
3. `{问题简称}_问题陈述书.md`
4. `{问题简称}_逻辑树.md`
5. `{问题简称}_工作计划表.md`
6. `{问题简称}_沟通故事板.md`

脚本仅依赖 Python 标准库；脚本不可用时可用 `references/templates.md` 手工产出。

## 边界

- 不编造数据、研究结果、用户访谈、案例或第三方授权；
- 不声称麦肯锡或任何第三方背书/授权/官方附属（SMART / MECE / 金字塔原理 / 七步问题解决法 / SCQA 仅作分析框架与描述性引用）；
- 不替用户做最终业务决策；
- 产物仅供内部讨论，外发、客户提案、法律承诺或商用前需法务、品牌、合规审查。
